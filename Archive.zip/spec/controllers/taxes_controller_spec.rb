require 'rails_helper'

RSpec.describe TaxesController, type: :controller do

end
