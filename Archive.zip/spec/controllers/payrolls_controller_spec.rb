require 'rails_helper'

RSpec.describe PayrollsController, type: :controller do

end
