require 'spec_helper'

describe PayrollDecorator do
end
