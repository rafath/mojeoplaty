require 'spec_helper'

describe TaxDecorator do
end
