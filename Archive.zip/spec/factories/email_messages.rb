FactoryGirl.define do
  factory :email_message do
    
  end

end
