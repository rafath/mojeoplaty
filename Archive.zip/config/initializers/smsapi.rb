SMSApi.configure do |config|
  config.username = ''
  config.password = ''
  config.password = ''
end