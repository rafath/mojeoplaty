<?php

$Video = new Video();
$d = (int)returnParam('d');
$id = (int)returnParam('id');

require_once(_SETTINGS . 'forms.php');
require_once(_SETTINGS . 'video_tags.php');
$form = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));

if (isset($dane_form)) {
  $form->setDefaults($dane_form);
}
array_shift($video_tags);
$form->addElement('textarea', 'video_url', 'linki do filmów:', 'class="col-xs-10 col-sm-5" id="video_url" rows="7"');
$form->addElement('select', 'tag', 'kategoria:', $video_tags, 'class="col-xs-10 col-sm-5" id="tag"');

$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-success" id="submit"');
$form->addElement('submit', 'submit_1', ' Zapisz i zostań na stronie ', 'class="btn btn-info" id="submit1"');
//if ($_POST) {
$form->applyFilter('__ALL__', 'trim');
$form->applyFilter('__ALL__', 'sanitize');

if ($form->validate() == true) {
  $Video->parseData($_POST);
  if (isset($_POST['submit_1'])) {
    $red_page = 'new_video';
  } else {
    $red_page = 'videos';
  }
  $red_url = url(array('ident' => $red_page, 'st' => 1));
  redirect($red_url);
}
//}
$form->accept($renderer);
$smarty->assign('form', $renderer->toArray());
/* end_form */
$smarty->assign('id', $id);
$smarty->assign(array(
  'id' => $id,
));