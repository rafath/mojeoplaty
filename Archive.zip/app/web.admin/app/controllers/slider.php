<?php
$o_Page = new Page();
$Slider = new Slider();
$d = (int)returnParam('d');
$id = (int)returnParam('id');
$pages = $o_Page->getParents(false, true);
//$pages = $o_Page->createCatsArray(0, 0, $pages);
require_once(_SETTINGS . 'forms.php');
$form = new HTML_QuickForm("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
if ($d == 2 and $id > 0) {
  $dane_form = $Slider->find($id);
  $form->addElement('hidden', 'd', $d);
  $form->addElement('hidden', 'id');
} else {
}
if (isset($dane_form)) {
  $form->setDefaults($dane_form);
}
$form->addElement('hidden', 'id');
$form->addElement('select', 'page_id', 'strona:', $pages, 'class="col-xs-12" id="page_id"');
$form->addElement('select', 'container', 'miejsce:', $sliders_container, 'class="col-xs-12" id="container"');
$form->addElement('text', 'short_description', 'krótki opis:', 'class="col-xs-12" id="short_description" size="30" maxlength="255"');
$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-submit" id="submit"');
if ($_POST) {
  $form->applyFilter('__ALL__', 'trim');
  $form->applyFilter('__ALL__', 'sanitize');
  $form->addRule('page_id', 'niepoprawny format danych', 'numeric');
  $form->addRule('container', 'niepoprawny format danych', 'numeric');
  $form->addRule('short_description', 'za dużo znaków (max: 255)', 'maxlength', 255);
  if ($form->validate() == true) {
    if ($d == 2 and $id > 0) {
      $Slider->update($_POST, $id);
    } else {
      $Slider->create($_POST);
    }
    $red_url = url(array('ident' => 'sliders', 'st' => 1));
    redirect($red_url);
    exit;
  }
}
$form->accept($renderer);
$smarty->assign('form', $renderer->toArray());
/* end_form */