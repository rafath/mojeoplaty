<?php

$o_Page = new Page();
$d = (int)returnParam('d');
$id = (int)returnParam('id');

/* start_form */
require_once(_SETTINGS . 'forms.php');
$form = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
if (($d == 2) and ($id > 0)) {
  $dane_form = $o_Page->getPage($id);
//  $dane_form['is_active'] = $dane_form['is_active'] == 't' ? 1 : 0;
//  $dane_form['is_main'] = $dane_form['is_main'] == 't' ? 1 : 0;
//  $dane_form['in_menu'] = $dane_form['in_menu'] == 't' ? 1 : 0;
  $form->addElement('hidden', 'd', $d);
  $form->addElement('hidden', 'id', $id);
  $form->addElement('hidden', 'old_main_picture_file_name', $dane_form['main_picture_file_name']);
  $form->addElement('hidden', 'old_wide_picture_file_name', $dane_form['wide_picture_file_name']);
  $form->addElement('hidden', 'old_site_picture_file_name', $dane_form['site_picture_file_name']);
  $form->addElement('checkbox', 'del_photo', 'usuń zdjęcie:', '', 'class="ace ace-switch ace-switch-6"');
  $form->addElement('checkbox', 'del_photo_1', 'usuń zdjęcie:', '', 'class="ace ace-switch ace-switch-6"');
  $form->addElement('checkbox', 'del_photo_2', 'usuń zdjęcie:', '', 'class="ace ace-switch ace-switch-6"');

} else {
  $dane_form = array('is_active' => 1, 'in_menu'=> 1, 'lang_id'=> $_SESSION['authinfo']['default_lang']);
}
if (isset($dane_form)) {
  $form->setDefaults($dane_form);
}
//$parents = $o_Page->getParents();
$pages = $o_Page->getPages();
$parents = $o_Page->createCatsArray(0,0,$pages);
$parents = array(0=> 'Nowa strona') + $parents;

$form->addElement('select', 'parent', 'strona:', $parents, 'class="col-xs-10 col-sm-5" id="parent"');
$form->addElement('select', 'lang_id', 'język:', $langs, 'class="col-xs-10 col-sm-5" id="langs"');
$form->addElement('text', 'short_title', 'tytuł do menu:', 'class="col-xs-10 col-sm-5" id="short_title" size="50" maxlength="64"');
$form->addElement('text', 'title', 'pełny tytuł:', 'class="col-xs-10 col-sm-5" id="title" size="50" maxlength="255"');
$form->addElement('textarea', 'description', 'opis:', 'class="col-xs-10 col-sm-5 summernote" id="description" rows="6"');
$form->addElement('text', 'seo_title', 'SEO tytuł:', 'class="col-xs-10 col-sm-5" id="seo_title" size="50" maxlength="255"');
$form->addElement('textarea', 'seo_description', 'SEO opis:', 'class="col-xs-10 col-sm-5" rows="5" id="seo_description"');
$form->addElement('textarea', 'seo_keywords', 'SEO słowa kluczowe:', 'class="col-xs-10 col-sm-5" id="seo_keywords"');
$form->addElement('file', 'main_picture_file_name', 'zdjęcie na główną:', 'class="col-xs-10 col-sm-5" id="main_picture_file_name"');
$form->addElement('file', 'wide_picture_file_name', 'zdjęcie panoramiczne:', 'class="col-xs-10 col-sm-5" id="wide_picture_file_name"');
$form->addElement('file', 'site_picture_file_name', 'zdjęcie na stronę:', 'class="col-xs-10 col-sm-5" id="site_picture_file_name"');
$form->addElement('text', 'website_url', 'link na zewnątrz:', 'class="col-xs-10 col-sm-5" id="website_url" size="50" maxlength="255"');
$form->addElement('text', 'theme_type', 'układ strony:', 'class="col-xs-10 col-sm-5" id="theme_type" size="15" maxlength="32"');
$form->addElement('text', 'sorter', 'kolejność:', 'class="col-xs-10 col-sm-5" id="sorter" size="10" maxlength="8"');
$form->addElement('text', 'uri_token', 'token url:', 'class="col-xs-10 col-sm-5" id="uri_token" size="50" maxlength="128"');
$form->addElement('checkbox', 'is_active', 'strona aktywna?', null, 'class="ace ace-switch ace-switch-6"');
$form->addElement('checkbox', 'is_main', 'umieść na stronie na głównej?', null, 'class="ace ace-switch ace-switch-6"');
$form->addElement('checkbox', 'in_menu', 'umieść w menu?', null, 'class="ace ace-switch ace-switch-6"');

$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-success" id="submit"');
$form->addElement('submit', 'submit_1', ' Zapisz i zostań na stronie ', 'class="btn btn-info" id="submit1"');
//if ($_POST) {
$form->applyFilter('__ALL__', 'trim');
$form->applyFilter('__ALL__', 'sanitize');
$form->addRule('short_title', 'pole wymagane', 'required', null, 'client');
$form->addRule('short_title', 'za dużo znaków (max: 64)', 'maxlength', 64, 'client');
$form->addRule('title', 'pole wymagane', 'required', null, 'client');
$form->addRule('title', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('seo_title', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
//$form->addRule('seo_description', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('seo_keywords', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('tstUpload', 'Zmniejsz logo, maks: 1 mb', 'maxfilesize', 1024000);
$form->addRule('website_url', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('theme_type', 'za dużo znaków (max: 32)', 'maxlength', 32, 'client');
$form->addRule('sorter', 'niepoprawny format danych', 'numeric', null, 'client');
$form->addRule('uri_token', 'za dużo znaków (max: 128)', 'maxlength', 128, 'client');
if ($form->validate() == true) {
  $o_FileUpload = new FileUpload($_FILES);
  if (!empty($_FILES['main_picture_file_name']['tmp_name'])) {
    $_POST['main_picture_file_name'] = $o_FileUpload->setUploadedFile('main_picture_file_name');
  }
  if (!empty($_FILES['wide_picture_file_name']['tmp_name'])) {
    $_POST['wide_picture_file_name'] = $o_FileUpload->setUploadedFile('wide_picture_file_name');
  }
  if (!empty($_FILES['site_picture_file_name']['tmp_name'])) {
    $_POST['site_picture_file_name'] = $o_FileUpload->setUploadedFile('site_picture_file_name');
  }

  if (($d == 2) && ($id > 0)) {
    $o_Page->editPage($_POST, $id);
  } else {
    $id = $o_Page->addPage($_POST);
  }
  if ($id > 0) {
    if (isset($_POST['submit_1'])) {
      $red_page = 'new_page';
    } else {
      $red_page = 'pages';
    }
    $red_url = url(array('ident' => $red_page, 'st' => 1));
    redirect($red_url);
    exit;
  }
}
//}
$form->accept($renderer);
/* end_form */
$smarty->assign(
  array(
    'form' => $renderer->toArray(),
    'page_data' => $dane_form,
  )
);