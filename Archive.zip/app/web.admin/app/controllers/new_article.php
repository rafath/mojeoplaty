<?php
$o_Page = new Page();
$Article = new Article();
$Gallery = new Gallery('file');
$d = (int)returnParam('d');
$id = (int)returnParam('id');
$img = (int)returnParam('img');
/* start_form */
if ($d == 3) {
  $Gallery->setSorting($_POST['sorter']);
  exit;
}
require_once(_SETTINGS . 'forms.php');
if ($id > 0) {
  if (isset($_POST['submit_2'])) {
    $o_FileUpload = new FileUpload($_FILES);
    if (!empty($_FILES['file']['tmp_name'])) {
      $filename = $o_FileUpload->setUploadedFile('file', $id, 'file', 'doc');
      $Gallery->addFile($filename, $id, $_POST['title']);
      redirect(url(['ident'=> 'new_article', 'id'=> $id, 'st'=> 1, 'd'=> 2]));

    }
  }
  $form_2 = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
  $form_2->addElement('file', 'file', 'plik', 'class="col-xs-10 col-sm-5"');
  $form_2->addElement('text', 'title', 'nazwa pliku:', 'class="col-xs-10 col-sm-5" id="title" size="50" maxlength="255"');
  $form_2->addElement('hidden', 'id', $id);
  $form_2->addElement('submit', 'submit_2', 'Dodaj plik', 'class="btn btn-success" id="submit2"');
  $form_2->accept($renderer);
  $smarty->assign('form_2', $renderer->toArray());

}
$form = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
if (($d == 2) and ($id > 0)) {
  $dane_form = $Article->getArticle($id);
  if ($dane_form['page_id'] == 7) {
    redirect(url(['ident'=> 'contact', 'id'=> $id, 'd'=> $d]));
  }
  $form->addElement('hidden', 'd', $d);
  $form->addElement('hidden', 'id');
  if ($img > 0) {
    $Gallery->deleteImage($img);
  }
  $gallery = $Gallery->getGalleries($id);
  $form->addElement('hidden', 'old_picture', $dane_form['picture']);
  $form->addElement('checkbox', 'del_photo', 'usuń zdjęcie:', '', 'class="ace ace-switch ace-switch-6"');
  $smarty->assign('page_data', $dane_form);
} else {
  $gallery = array();
}
if (isset($dane_form)) {
  $form->setDefaults($dane_form);
}
$pages = $o_Page->getPages();
$parents = $o_Page->createCatsArray(0, 0, $pages);
$form->addElement('file', 'picture', 'zdjęcie', 'class="col-xs-10 col-sm-5" id="picture"');
$form->addElement('select', 'page_id', 'strona:', $parents, 'class="col-xs-10 col-sm-5" id="page_id"');
$form->addElement('text', 'seo_title', ' SEO Tytuł:', 'class="col-xs-10 col-sm-5" id="seo_title" size="50" maxlength="255"');
$form->addElement('text', 'seo_keywords', 'SEO słowa kluczowe:', 'class="col-xs-10 col-sm-5" id="seo_keywords" size="50" maxlength="255"');
$form->addElement('textarea', 'seo_description', 'SEO krótki opis:', 'class="col-xs-10 col-sm-5" id="seo_description" size="50" maxlength="255"');
$form->addElement('text', 'title', 'Tytuł artykułu:', 'class="col-xs-10 col-sm-5" id="title" size="50" maxlength="255"');
$form->addElement('textarea', 'short_description', 'krótki opis:', 'class="col-xs-10 col-sm-5" id="short_description" rows="10"');
$form->addElement('textarea', 'description', 'Pełny opis:', 'class="col-xs-10 col-sm-5 summernote" id="description" style="width: 400px; height: 100px;"');
$form->addElement('text', 'uri_token', 'token url:', 'class="col-xs-10 col-sm-5" id="uri_token" size="50" maxlength="255"');
$form->addElement('select', 'status', 'status:', $article_status, 'class="col-xs-10 col-sm-5" id="status"');
$form->addElement('text', 'sorter', 'kolejność:', 'class="col-xs-10 col-sm-5" id="sorter" size="10" maxlength="8"');
$form->addElement('checkbox', 'main_page', 'umieść na głównej?', null, 'class="ace ace-switch ace-switch-6"');
$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-success" id="submit"');
$form->addElement('submit', 'submit_1', ' Zapisz i zostań na stronie ', 'class="btn btn-info" id="submit1"');
$form->addElement('hidden', 'fullform', '1');
//if ($_POST) {
$form->applyFilter('__ALL__', 'trim');
$form->applyFilter('__ALL__', 'sanitize');
$form->addRule('seo_title', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('seo_keywords', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
//$form->addRule('seo_description', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('title', 'Pole wymagane', 'required', null, 'client');
//$form->addRule('description', 'Pole wymagane', 'required', null, 'client');
$form->addRule('title', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
//$form->addRule('short_description', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('uri_token', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
if (isset($_POST['fullform'])) {
  if ($form->validate() == true) {
    $o_FileUpload = new FileUpload($_FILES);
    if (!empty($_FILES['picture']['tmp_name'])) {
      $_POST['picture'] = $o_FileUpload->setUploadedFile('picture');
    }
    if (($d == 2) and ($id > 0)) {
      $Article->updateArticle($_POST, $id);
    } else {
      $Article->createArticle($_POST);
    }
    if (isset($_POST['submit_1'])) {
      $red_page = 'new_article';
    } else {
      $red_page = 'articles';
    }
    $red_url = url(array('ident' => $red_page, 'st' => 1));
    redirect($red_url);
  }
}
$form->accept($renderer);
$smarty->assign(array(
  'form' => $renderer->toArray(),
  'id' => $id,
  'gallery' => $gallery,
));