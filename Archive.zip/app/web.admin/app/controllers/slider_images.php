<?php
$o_Page = new Page();
$SliderImage = new SliderImage();
$Slider = new Slider();
$d = (int)returnParam('d');
$slider_id = (int)returnParam('slider_id');
$id = (int)returnParam('id');
if ($d == 1 and $id > 0) {
  $SliderImage->delete($id);
}
$sliders = $Slider->findAssoc();
/* start_form */
require_once(_SETTINGS . 'forms.php');
$form = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
if ($d == 2 and $id > 0) {
  $dane_form = $SliderImage->find($id);
  $form->addElement('hidden', 'd', $d);
  $form->addElement('hidden', 'id');
  $form->addElement('hidden', 'old_image', $dane_form['image']);
  $form->addElement('checkbox', 'del_photo', 'usuń zdjęcie:', '', 'class="ace ace-switch ace-switch-6"');
} else {
  $dane_form['sorter'] = '0';
  $dane_form['slider_id'] = $slider_id;
}
if (isset($dane_form)) {
  $form->setDefaults($dane_form);
}
$form->addElement('select', 'slider_id', 'Slider:', $sliders, 'class="input-xlarge" id="slider_id"');
$form->addElement('text', 'sorter', 'kolejność:', 'class="input-small" id="sorter" placeholder="sorter" size="10" maxlength="8"');
$form->addElement('file', 'image', 'zdjęcie slajdu:', 'class="col-xs-10 col-sm-5" id="image"');
$form->addElement('text', 'title', 'nazwa slajdu:', 'class="input-xlarge" id="title" size="30" maxlength="255"');
$form->addElement('textarea', 'description', 'treść:', 'class="summernote" id="description" placeholder="description" style="width: 400px; height: 100px;"');
$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-submit" id="submit"');
//if ($_POST) {
$form->applyFilter('__ALL__', 'trim');
$form->applyFilter('__ALL__', 'sanitize');
$form->addRule('slider_id', 'niepoprawny format danych', 'numeric', null, 'client');
$form->addRule('sorter', 'niepoprawny format danych', 'numeric', null, 'client');
$form->addRule('image', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
$form->addRule('title', 'za dużo znaków (max: 255)', 'maxlength', 255, 'client');
if ($form->validate() == true) {
  $o_FileUpload = new FileUpload($_FILES);
  if (!empty($_FILES['image']['tmp_name'])) {
    $_POST['image'] = $o_FileUpload->setUploadedFile('image', 2, 'slider');
  }
  if ($d == 2 and $id > 0) {
    $SliderImage->update($_POST, $id);
  } else {
    $SliderImage->create($_POST);
  }
  $red_url = url(array('ident' => $ident, 'st' => 1, 'slider_id' => $slider_id));
  redirect($red_url);
}
$form->accept($renderer);
$smarty->assign('form', $renderer->toArray());
$smarty->assign('slider_image', $dane_form);
$smarty->assign('slider_images', $SliderImage->findAll($slider_id));
$smarty->assign('sliders', $sliders);
$smarty->assign('slider_id', $slider_id);