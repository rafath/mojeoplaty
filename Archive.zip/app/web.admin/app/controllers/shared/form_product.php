<?php

$a_xajax_fn = array('showProductTypeForm');
require_once(_VENDORS . 'xajax/xajaxengine.php');
$js_c_net = "calcPrice(1);";
$js_c_brut = "calcPrice(2);";
$js_c_vat = "calcPrice(3);";
$js_rabat = "calcPrice(8);";
$js_rabat_price = "calcPrice(7);";
$js_marza = "calcPrice(4);";
$js_marza_netto = "calcPrice(5);";
$js_marza_brutto = "calcPrice(6);";
$js_prod_name = "CopyName('name_long', 'name_short', 128)";
//$js_producent = "onChange='checkProducent();'";
$sel_style = ' style="width: 259px;"';
$o_Categories = new Categories();
$categories = $o_Categories->getMainCategories();
$smarty->assign('categories', $categories);
if (!isset($o_Ucategories)) {
  $o_Ucategories = new Ucategories();
}
$a_ucategories = $o_Ucategories->getUcategoriesAssocTree();
$form->addElement('select', 'ucategories', 'kategoria:', $a_ucategories, 'class="input select-input with_help with_pin" multiple="multiple" id="ucategories" size="1"');
$form->addElement('text', 'name_long', 'pełna nazwa produktu:', 'class="input" size="60" maxlength="200" onBlur="' . $js_prod_name . '"');
$form->addElement('text', 'name_short', 'skrócona nazwa:', 'class="input" size="50" maxlength="128"');
$form->addElement('text', 'ean', 'kod kreskowy (EAN):', 'class="input" size="30" maxlength="128"');
$form->addElement('select', 'currency', 'waluta:', $walutat_tab, 'class="select with_pin" size="1" onChange="' . $js_c_vat . '"');
$form->addElement('select', 'vat', 'stawka vat:', $vat_tab, 'class="input select-input with_pin" size="1" onChange="' . $js_c_vat . '"');
$form->addElement('text', 'c_netto', 'cena produktu netto:', 'class="input" size="6" maxlength="8" onkeyup="' . $js_c_net . '" onclick="this.select()"');
$form->addElement('text', 'c_brutto', 'brutto:', 'class="input" size="6" maxlength="8" onkeyup="' . $js_c_brut . '" onclick="this.select()"');
$form->addElement('text', 'c_producent', 'cena producenta netto:', 'class="input" size="6" maxlength="8" onkeyup="' . $js_marza_netto . '"');
$form->addElement('text', 'c_producent_brutto', 'brutto:', 'class="input" size="6" maxlength="8" onkeyup="' . $js_marza_brutto . '"');
$form->addElement('text', 'marza', 'narzut:', 'class="input" size="6" maxlength="8" onkeyup="' . $js_marza . '"');
$form->addElement('text', 'rabat', 'rabat procentowy:', 'class="input" size="6" maxlength="4" onkeyup="'.$js_rabat.'"');
$form->addElement('text', 'rabat_price', 'kwotowy (brutto):', 'class="input" size="10" onkeyup="'.$js_rabat_price.'"');
$form->addElement('text', 'promo_start', 'start promocji:', 'class="datepicker input-unstyled" size="20"');
$form->addElement('text', 'promo_end', 'koniec promocji:', 'class="datepicker input-unstyled" size="20" maxlength="2"');

$form->addElement('text', 'ilosc', 'ilość i jednostka:', 'class="input with_pin" size="6" maxlength="10" onclick="this.select()"');
$form->addElement('text', 'punkty', 'punkty:', 'class="input" size="6" maxlength="10"');
$form->addElement('text', 'waga', 'waga:', 'class="input with_pin" size="6" maxlength="10"');
$form->addElement('select', 'weight_type', '', array(0 => 'g', 1 => 'kg'), 'class="select with_pin"');
$form->addElement('text', 'nr_katalog', 'nr katalogowy:', 'class="input" size="15" maxlength="32"');
$form->addElement('text', 'kod_producenta', 'kod producenta:', 'class="input" size="15" maxlength="122"');
$form->addElement('text', 'jednostka', 'jednostka:', 'class="input with_pin" size="15" maxlength="32"');
$form->addElement('select', 'supplier_id', 'wybierz dostawcę:', $suppliers, 'class="select with_pin"' . $sel_style);
$form->addElement('select', 'producent_id', 'wybierz producenta:', $producenci, 'class="select with_pin"' . $sel_style);
$form->addElement('text', 'producent', 'lub wpisz:', 'class="input" size="30" maxlength="128"');
$form->addElement('text', 'url_prod', 'link do producenta:', 'class="input with_help" size="30" maxlength="128"');
$form->addElement('select', 'rodzaj', 'stan:', $rodzaj_tab, 'class="select"' . $sel_style);
$form->addElement('select', 'przesylka', 'czas oczekiwania:', $przesylka_tab, 'class="select with_help"' . $sel_style);
$form->addElement('select', 'status', 'status na magazynie:', $status_tab, 'class="select with_help"' . $sel_style);
$form->addElement('select', 'dzial', 'dział:', $dzial_tab, 'class="select with_help"' . $sel_style);
$form->addElement('select', 'grupa_id', 'wybierz zestaw:', $grupy, 'class="select with_help"' . $sel_style);
$form->addElement('checkbox', 'str_gl_user', 'strona główna:', '', 'class="switch green-active" data-text-on="tak" data-text-off="nie"');
$form->addElement('checkbox', 'status_shop', 'wystawić w sklepie?', '', 'class="switch green-active" data-text-on="tak" data-text-off="nie"');
//$form->addGroup($radio, 'str_gl_user', 'strona główna:', '</span><span>');
//$form->addGroup($radio1, 'status_shop', 'wystawić w sklepie?', '</span><span>');
$form->addElement('file', 'tstUpload', 'zdjęcie:', 'class="file" id="tstUpload"');
$form->addElement('text', 'picture_url', 'lub link do zdjęcia:', 'class="input" size="40"');
$licznik_js = "onkeydown=\"licznik('form_{$ident}_1', 'zajawka', 'cnt_zajawka', 500);\" onblur=\"licznik('product_form', 'zajawka', 'cnt_zajawka', 500);\"";
$form->addElement('textarea', 'zajawka', 'krótki opis:', 'class="input with_help" rows="6" cols="65" ' . $licznik_js);
$licznik_js = "onkeydown=\"licznik('form_{$ident}_1', 'keywords', 'cnt_keywords', 250);\" onblur=\"licznik('product_form', 'keywords', 'cnt_keywords', 250);\"";
$form->addElement('textarea', 'keywords', 'słowa kluczowe:', 'class="input with_help" rows="3" cols="65"' . $licznik_js);
$form->addElement('text', 'cnt_zajawka', 'zostało:', 'class="input" size="4" readonly="readonly"');
$form->addElement('text', 'cnt_keywords', 'zostało:', 'class="input" size="4" readonly="readonly"');
$form->addElement('textarea', "opis", 'opis produktu:', tinyMceStr("opis"));
$form->addElement('select', 'redirect', 'oraz', $a_redirect_tab, 'class="select with_pin"');
$form->addElement('hidden', 's', returnParam('s'));
$form->addElement('hidden', 'va', '00');
//$form->addElement('hidden', 'subcategoryb');
//$form->addElement('hidden', 'bkid', $bkid);
$selects = array(0 => "");
//czesc js do formularzy
$form->addElement('select', 'selectFirst', null, $selects, 'class="input category_selects" size="14" id="sellFormSelectFirst"');
$form->addElement('select', 'selectSecond', null, $selects, 'class="input category_selects" size="14" id="sellFormSelectSecond" ');
$form->addElement('select', 'selectThird', null, $selects, 'class="input category_selects" size="14" id="sellFormSelectThird" ');
$form->addElement('text', 'categoryBox', 'numer kategorii:', 'class="input with_pin" size="5" maxlength="6" id="sellFormCategoryBox"');
$form->addElement('hidden', 'categoryTree', null, 'id="sellFormCategoryTree"');
$form->addElement('hidden', 'category', null, 'id="sellFormCategory"');
$form->addElement('submit', 'submit', ' Wykonaj ', 'class="button green-gradient glossy" onclick="return button_click(this, null);"');
function price($price) {

  $price = convFloat($price);
  return is_numeric($price);
}

//function checkMsoTag($field) {
//    if (preg_match('/(class="MsoNormal")/i', $field)) return false;
//    else return true;
//}
//function checkUcategory($field) {
//  global $o_Produkty;
//  if ($o_Produkty->checkCategoryId($field, 'ucat') == false) {
//    return false;
//  }
//  else {
//    return true;
//  }
//}
function checkCategory($field) {

  global $o_Produkty;
  if ($o_Produkty->checkCategoryId($field) == false) {
    return false;
  } else {
    return true;
  }
}

$form->addRule('categoryBox', "pole wymagane", 'required', null, 'client');
$form->addRule('categoryBox', 'wybierz poprawną kategorię', 'callback', 'checkCategory');
$form->addRule('ucategories', "pole wymagane", 'required', null, 'client');
//$form->addRule('ucategories', 'wybierz kategorię w sklepie', 'callback', 'checkUcategory');
$form->addRule('name_long', "pole wymagane", 'required', null, 'client');
$form->addRule('name_long', 'zbyt krótka nazwa (min 2 - 200 znaków!)', 'rangelength', array(2, 200), 'client');
$form->addRule('name_short', "pole wymagane", 'required', null, 'client');
$form->addRule('name_short', 'zbyt długa nazwa (do 128 znakow!)', 'maxlength', 128, 'client');
$form->addRule('rabat', "pole wymagane", 'required', null, 'client');
$form->addRule('rabat', "niewłaściwy format danych", 'numeric', null, 'client');
$form->addRule('ilosc', "pole wymagane", 'required', null, 'client');
$form->addRule('ilosc', "niewłaściwy format danych", 'numeric', null, 'client');
//$form->addRule('keywords', "pole wymagane", 'required', null, 'client');
$form->addRule('keywords', 'maximum 255 znaków!', 'maxlength', 255, 'client');
$form->addRule('waga', "pole wymagane", 'required', null, 'client');
$form->addRule('waga', "niewłaściwy format danych", 'numeric', null, 'client');
$form->addRule('c_netto', "pole wymagane", 'required', null, 'client');
$form->addRule('c_netto', "niewłaściwy format danych", 'callback', 'price');
$form->addRule('c_brutto', "niewłaściwy format danych", 'callback', 'price');
$form->addRule('jednostka', 'niedozwolone znaki', 'regex', '/^[0-9a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ\.\,\-_\s]+$/', 'client');
$form->addRule('jednostka', 'dopuszczalna ilość maks 32 znaki', 'maxlength', 32, 'client');
$form->addRule('tstUpload', 'Max: 1MB', 'maxfilesize', 1048000);
$form->addRule('tstUpload', 'nieprawidłowy format pliku', 'mimetype', $o_FileUpload->imgmimetype);
$form->addRule('tstUpload', 'za duże rozmiary pliku (dopuszczalne wymiary: ' . $o_FileUpload->max_width . ' x ' . $o_FileUpload->max_height . ')', 'callback', '_validateSize');
$form->addRule('opis', "pole wymagane", 'required', null, 'client');
$form->addRule('opis', 'opis produktu powinien mieć co najmniej 10 znaków', 'minlength', 10, 'client');
//$form->addRule('opis', 'Wyczyścić opis z tagów z programu Word. Skorzystaj z ikonki "wklej z Worda".', 'callback', 'checkMsoTag');
/*if ($_SESSION['activeshop']['id'] == 11255 or $_SESSION['activeshop']['id'] == 6799 or $_SESSION['activeshop']['id'] == 2) {
  $a_modules = $o_ModuleInfo->getModuleInfoList();
  $modules[0] = '--------- brak --------';
  foreach ($a_modules as $value) {
    $modules[$value['id']] = $value['module_name'];
  }
  $form->addElement('select', 'prod_modules', 'dodatkowe moduły:', $modules, 'class="formfield large" multiple="true" size="10"');
}*/
$a_product_type = array(
  0 => ' ------------- wybierz ------------- ',
  'product_books' => 'Książki',
  'product_games' => 'Gry PC / Gry na konsole',
  'product_medicines' => 'Leki, suplementy',
  'product_movies' => 'Filmy',
  'product_music' => 'Płyty muzyczne',
  'product_perfumes' => 'Perfumy',
  'product_rims' => 'Felgi i kołpaki',
  'product_tires' => 'Opony',
);
$form->addElement('select', 'product_type', 'Wybierz grupę produktów:', $a_product_type, 'class="select with_help" size="1" id="product_type"');
