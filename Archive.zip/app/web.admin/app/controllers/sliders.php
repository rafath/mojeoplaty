<?php
$o_Page = new Page();
$Slider = new Slider();
$d = (int)returnParam('d');
$id = (int)returnParam('id');
if ($d == 1 and $id > 0) {
  $Slider->delete($id);
}
$pages = $o_Page->getParents(false);
//$pages = $o_Page->createCatsArray(0, 0, $pages);
$smarty->assign(array(
  'sliders' => $Slider->findAll(),
  'pages' => $pages,
));