<?php
$t = returnParam('t');
$id = (int)returnParam('id');
$d = (int)returnParam('d');
$n = returnParam('n');
$Gallery = new Gallery();
if ($d > 0) {
  $picture = $Gallery->getGallery($id, $n);
  if (!empty($picture)) {
    $Gallery->deletePicture($picture['article_id'], $picture['picture']);
  }
  $Gallery->delGallery($id, $n);
} else {
  $o_FileUpload = new FileUpload($_FILES);
  $name = $o_FileUpload->setUploadedFile('picture', $id);
  $Gallery->createGallery(array('article_id' => $id, 'picture' => $name, 'picture_orig_name' => $_FILES['picture']['name']));
}
