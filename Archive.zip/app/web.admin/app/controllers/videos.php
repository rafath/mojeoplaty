<?php
$o_Page = new Page();
$Video = new Video();

require_once(_SETTINGS . 'video_tags.php');

$d = (int)returnParam('d');
$id = (int)returnParam('id');
$f = (int)returnParam('f');
if ($d == 2 and $id > 0) {
  $Video->setNew($id, $f);
  echo 'ok';
  exit;
}
if ($d == 3 and $id > 0) {
  $Video->setSize($id, $f, 'width');
  echo 'ok';
  exit;
}
if ($d == 4 and $id > 0) {
  $Video->setSize($id, $f, 'height');
  echo 'ok';
  exit;
}

if ($d == 1 and $id > 0) {
  $video = $Video->getVideo($id);
  $o_FileUpload = new FileUpload();
  $o_FileUpload->deleteFile(0, $video['picture']);
  $Video->delVideo($id);
}
$smarty->assign(
  array(
    'pages'=> $o_Page->getParents(false),
    'videos' => $Video->getVideos(50),
  )
);