<?php
//get new orders
//todo: 1. admin  - porządek z uploadem
//todo: admin: sciezki do fotek (potem punktowe, cms, logo (wg id rekordu!) sklepu, etc)
//todo; 2. sklep - fotki i sciezki
//$o_ImageConverter = new ImageConverter( 1, 2);
//$o_ImageConverter->getRemoteProduct();
//$o_ImageConverter->getLocalProducts();


require_once(_SETTINGS . 'forms.php');
$form = new HTML_QuickForm_DHTMLRules("form_1", 'POST', url(array('ident' => 'domains')));
$form->addElement('text', 'domain_name', 'www.', 'class="formfield" size="30" maxlength="250"');
$form->addElement('submit', 'submit', 'Sprawdź', 'class="button green-gradient glossy"');
$form->addElement('hidden', 'index');
$form->setDefaults(array('index' => '1'));
$form->addRule('domain_name', 'pole wymagane', 'required', null, 'client');
$form->accept($renderer);
$smarty->assign(
  array(
//    'formDomains' => $renderer->toArray(),
  )
);