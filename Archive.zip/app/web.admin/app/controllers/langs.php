<?php
$SiteLang = new SiteLang();

$d = (int)returnParam('d');
$id = (int)returnParam('id');

if ($d == 1 and $id > 0) {
  $SiteLang->delete($id);
}

$langs = $SiteLang->findAll();
$smarty->assign('langs', $langs);