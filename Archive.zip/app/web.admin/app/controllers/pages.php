<?php
$o_Page = new Page();

$d = (int)returnParam('d');
$id = (int)returnParam('id');

if ($d == 1 and $id > 0) {
  $page = $o_Page->getPage($id);
  $o_Page->deletePicture(0, $page['main_picture_file_name']);
  $o_Page->deletePicture(0, $page['wide_picture_file_name']);
  $o_Page->deletePicture(0, $page['site_picture_file_name']);
  $o_Page->delPage($id);
}

$smarty->assign(
  array(
    'pages' => $o_Page->getPages(),
  )
);