<?php
$d = (int)returnParam('d');
$id = (int)returnParam('id');
require_once(_SETTINGS . 'forms.php');
$form = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
$form->addElement('file', 'picture', 'zdjęcie:', 'class="col-xs-10 col-sm-5" id="picture" multiple');
$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-success" id="submit"');
$form->applyFilter('__ALL__', 'trim');
$form->applyFilter('__ALL__', 'sanitize');
$form->accept($renderer);
$smarty->assign(
  array(
    'form' => $renderer->toArray(),
    'id' => $id,
  )
);