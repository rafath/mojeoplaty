<?php
$SiteLang = new SiteLang();
$d = (int)returnParam('d');
$id = (int)returnParam('id');
/* start_form */
require_once(_SETTINGS . 'forms.php');
$form = new HTML_QuickForm_DHTMLRules("form_{$ident}_1", 'POST', url(array('ident' => $ident)));
if ($d == 2 and $id > 0) {
  $dane_form = $SiteLang->find($id);
  $form->addElement('hidden', 'd', $d);
  $form->addElement('hidden', 'id');
//  $dane_form['is_active'] = $dane_form['is_active'] == 't' ? 1 : 0;
} else {
}
if (isset($dane_form)) {
  $form->setDefaults($dane_form);
}
$form->addElement('text', 'name', 'nazwa języka:', 'class="col-xs-12" id="name" size="15" maxlength="32"');
$form->addElement('text', 'locale_name', 'ustawienia locale:', 'class="col-xs-12" id="locale_name" size="15" placeholder="pl_PL.UTF-8" maxlength="32"');
$form->addElement('text', 'prefix', 'prefiks:', 'class="col-xs-12" id="prefix" size="15" placeholder="pl" maxlength="32"');
$form->addElement('checkbox', 'is_active', 'czy dostępny:', null, 'class="ace ace-switch ace-switch-6"');
$form->addElement('submit', 'submit', ' Zapisz zmiany ', 'class="btn btn-submit" id="submit"');
$form->applyFilter('__ALL__', 'trim');
$form->applyFilter('__ALL__', 'sanitize');
$form->addRule('name', 'pole wymagane', 'required', null, 'client');
$form->addRule('name', 'za dużo znaków (max: 32)', 'maxlength', 32, 'client');
$form->addRule('locale_name', 'za dużo znaków (max: 32)', 'maxlength', 32, 'client');
if ($form->validate() == true) {
  if ($d == 2 and $id > 0) {
    $SiteLang->update($_POST, $id);
  } else {
    $SiteLang->create($_POST);
  }
  $red_url = url(array('ident' => 'langs', 'st' => 1));
  redirect($red_url);
}
$form->accept($renderer);
$smarty->assign('form', $renderer->toArray());
/* end_form */