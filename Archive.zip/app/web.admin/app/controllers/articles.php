<?php
$o_Page = new Page();
$Article = new Article();

$d = (int)returnParam('d');
$id = (int)returnParam('id');
if ($d == 1 and $id > 0) {
  $Article->delArticle($id);
}
$smarty->assign(
  array(
    'pages'=> $o_Page->getParents(false, true),
    'articles' => $Article->getArticles(200),
  )
);