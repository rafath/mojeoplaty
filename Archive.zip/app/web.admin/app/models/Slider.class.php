<?php

class Slider extends AdminEngine {

  function __construct() {

    parent::__construct();
  }

  /**
   *
   * @return array
   */
  public function findAll($limit = 50, $offset = 0) {

    return $this->selectAll('sliders', array(), '*', 'order by id', $limit, $offset);
  }

  public function findAssoc() {

    return $this->selectAssoc('sliders', null, 'id, short_description', 'order by id asc');
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array
   */
  public function find($id) {

    return $this->selectRow('sliders', $id);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return mixed
   */
  public function create($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'page_id' => (int)$page_id,
      'container' => (int)$container,
      'short_description' => $short_description,
    );
    return $this->autoInsertQuery('sliders', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  public function update($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'page_id' => (int)$page_id,
      'container' => (int)$container,
      'short_description' => $short_description,
    );
    return $this->autoUpdateQuery('sliders', $fields, $id);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  public function delete($id) {
    $this->autoDeleteQuery('slider_images', array('slider_id'=> $id));
    return $this->autoDeleteQuery('sliders', $id);
  }
}
