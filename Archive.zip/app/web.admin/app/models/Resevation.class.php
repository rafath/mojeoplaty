<?php

class Reservation extends AdminEngine {

  function __construct() {

    parent::__construct();
  }

  /**
   *
   * @return array $res
   */
  function getReservations($limit = 20, $offset = 0) {

    return $this->selectAll('reservations', array(), '*', '', $limit, $offset);
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array $res
   */
  function getReservation($id) {

    return $this->selectRow('reservations', $id);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return bool
   */
  function createReservation($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'email' => $email,
      'phone' => $phone,
      'client_name' => $client_name,
      'date_from' => '{NOW()}',
      'date_to' => '{NOW()}',
      'ship_type' => (int)$ship_type,
      'journey' => (int)$journey,
      'notes' => $notes,
      'people_amount' => (int)$people_amount,
      'is_paid' => $is_paid,
      'paid_amount' => $paid_amount,
      'amount' => $amount,
      'invoice_number' => (int)$invoice_number,
      'created_at' => '{NOW()}',
      'updated_at' => '{NOW()}',
    );
    return $this->autoInsertQuery('reservations', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  function updateReservation($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'email' => $email,
      'phone' => $phone,
      'client_name' => $client_name,
      'date_from' => '{NOW()}',
      'date_to' => '{NOW()}',
      'ship_type' => (int)$ship_type,
      'journey' => (int)$journey,
      'notes' => $notes,
      'people_amount' => (int)$people_amount,
      'is_paid' => $is_paid,
      'paid_amount' => $paid_amount,
      'amount' => $amount,
      'invoice_number' => (int)$invoice_number,
      'created_at' => '{NOW()}',
      'updated_at' => '{NOW()}',
    );
    return $this->autoUpdateQuery('reservations', $fields, $id);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  function delReservation($id) {

    return $this->autoDeleteQuery('reservations', $id);
  }
}
