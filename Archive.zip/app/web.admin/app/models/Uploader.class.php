<?php
/**
 * klasa uploadujaca pliki na serwer/roznego rodzaju
 *
 * parametry wymagane:
 * $img_dir_upl - katalog docelowy
 *
 *

include_once(_MODELS."Uploader.class.php");  //pamietaj o ustawnieniu sciezki do klasy HTTP_Upload
$OBJuploader = new Uploader($dir_www);
$foto_dane = $OBJuploader->uploadFile('id1'); //id1 = nazwa pola w formularzu
$_POST['id1'] = $foto_dane['name'];

//rozne rozmiary:
$OBJuploader->miniaturka(IMG_MIN, IMG_MIN_NAME, null, false);
$OBJuploader->miniaturka(IMG_MED, IMG_MED_NAME, null, false);
$OBJuploader->miniaturka(IMG_MAX, IMG_MAX_NAME, null, true);
 *
 * @author : rafath khan
 * @version: 0.1 stable
 * @final  : 2006.05.03 12:00
 */
/*
define ("IMG_MIN", 60);
define ("IMG_MED", 100);
define ("IMG_MAX", 250);
define ("RATIO_90", 90);
define ("IMG_MAX_RATIO_W", 200);
define ("IMG_MAX_RATIO_H", 0);

//okresniele nazw plikow
define ("IMG_MIN_NAME", '60_');
define ("IMG_MED_NAME", '100_');
define ("IMG_MAX_NAME", "250_");
define ("IMG_RATIO_90", "90_");
define ("IMG_MAX_RATIO_NAME", "200_");
*/

//include_once(_MODELS . "HTTP_Upload.class.php");
class Uploader extends HTTP_Upload {
  public $dest_name, $img_dir_upl, $foto_prop, $mime;
  public $file_name = 'uniq'; // real || uniq || safe
  public $max_width = 2001;
  public $max_height = 2001;
  public $quality = 80;
  public $imageExtentions = array('jpg', 'gif', 'jpeg', 'jpg', 'png', 'x-png', 'swf', 'psd', 'tif', 'zip');
  public $soundExtentions = array('wav', 'mp3', 'midi');
  //public $videoExtentions = array('wmv', 'asf', 'avi');
  public $videoExtentions = array();
  public $docExtentions = array('pdf', 'doc', 'txt', 'rtf', 'xls', 'csv', 'docx', 'xlsx', 'zip', 'tgz', 'gz');
  public $registered_types = array(
    "application/x-gzip-compressed" => ".tar.gz, .tgz",
    "application/x-zip-compressed" => ".zip",
    "application/zip" => ".zip",
    "application/x-tar" => ".tar",
    //"text/plain" => ".html, .php, .txt, .inc (etc)",
    "text/plain" => ".txt",
    "text/xml" => ".xml",
    //"image/bmp" => ".bmp, .ico",
    "audio/mpeg" => ".mp3",
    "image/gif" => ".gif",
    "image/pjpeg" => ".jpg, .jpeg",
    "image/jpeg" => ".jpg, .jpeg",
    "image/x-png" => ".png",
    "image/png" => ".png",
    'image/psd' => ".psd",
    'image/vnd.adobe.photoshop' => ".psd",
    'image/tiff' => ".tif",
    "application/x-shockwave-flash" => ".swf",
    "application/msword" => ".doc",
    "application/pdf" => ".pdf",
    "application/vnd.ms-excel" => ".xls",
    "text/css" => ".css",
    "application/octet-stream" => ".exe, .fla, .csv",
    "application/csv" => ".csv",
    "text/csv" => ".csv",
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => '.xlsx',
  );
  public $allowed_types = array(
    //"image/bmp",
    "image/gif",
    "image/pjpeg",
    "image/jpeg",
    "image/x-png",
    "image/png",
    "audio/mpeg",
    "application/msword",
    "application/pdf",
    "application/zip",
    "text/css",
    "text/plain",
    "application/x-zip-compressed",
    "application/x-shockwave-flash",
    "application/vnd.ms-excel",
    "application/octet-stream",
    "application/csv",
    'image/tiff',
    "text/xml",
    "text/csv",
    'image/vnd.adobe.photoshop',
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  );
  public $imgmimetype = array(
    "image/gif",
    "image/pjpeg",
    "image/jpeg",
    "image/x-png",
    "image/png",
    'image/gif',
    'application/x-shockwave-flash',
    'image/psd',
    'image/vnd.adobe.photoshop',
    'image/bmp',
    'image/tiff',
    'application/octet-stream',
    'image/jp2',
    'application/x-shockwave-flash',
    'image/vnd.wap.wbmp',
    //'image/xbm'
  );

  /**
   * konstruktor klasy
   *
   * @param string $img_dir_upl katalog docelowy
   *
   * @return Uploader
   */
  function Uploader($img_dir_upl, $file_name = 'uniq') {

    $this->http_upload('en');
    $this->img_dir_upl = $img_dir_upl;
    if (!is_dir($this->img_dir_upl)) {
      mkdir($this->img_dir_upl, 0775);
      umask(0002);
    }
    $this->file_name = $file_name;
  }

  /**
   * funkcja uploadujaca plik
   * (w przyszlosci dorobic sprawdzanie podawanych warunkow!)
   *
   * @param string $post_file_name nazwa pola formularza
   * @param string $types          dopuszczalny typ plikow
   *
   * @return array $file_prop - tablica danych dotyczacych uploadowanego pliku
   */
  function uploadFile($post_file_name, $types = 'image', $id = null) {

    if (!empty($id)) {
      $this->uploadDirById($id);
    }
    $file = $this->getFiles($post_file_name);
    if (PEAR::isError($file)) {
      die ($file->getMessage());
    }
    if ($types == 'image') {
      $size = getimagesize($file->upload['tmp_name']);
      if (($size[0] > $this->max_width) || ($size[1] > $this->max_height)) {
        return -1;
      }
    }
    if ($file->isValid()) {
      $file->setName($this->file_name);
      switch ($types) {
        case 'sound':
          $allowed_ext = $this->soundExtentions;
          break;
        case 'video':
          $allowed_ext = $this->videoExtentions;
          break;
        case 'doc':
          $allowed_ext = $this->docExtentions;
          break;
        case 'all':
          $allowed_ext = array_merge($this->imageExtentions, $this->soundExtentions,
            $this->videoExtentions, $this->docExtentions);
          break;
        //tylko images
        default:
          $allowed_ext = $this->imageExtentions;
          break;
      }
      // extension sie nie zgadza
      if (!in_array(strtolower($file->getProp('ext')), $allowed_ext)) {
        return 1;
      }
      if (!in_array(strtolower($file->getProp('type')), $this->allowed_types)) {
        return 2;
      }
      //zakladam katalog dla fotek tego produktu
      if (!is_dir($this->img_dir_upl)) {
        mkdir($this->img_dir_upl, 0775);
        umask(0002);
      }
      $this->dest_name = $file->moveTo($this->img_dir_upl);
      if (PEAR::isError($this->dest_name)) {
        die ($this->dest_name->getMessage());
      }
      $real = $file->getProp('real');
    } elseif ($file->isMissing()) {
      $blad_add['msg'] = "<li>No file selected</li>\n";
      $blad_add['nr'] = 1;
    } elseif ($file->isError()) {
      $blad_add['msg'] = "<li>" . $file->errorMsg() . "</li>\n";
      $blad_add['nr'] = 1;
    }
    return $this->foto_prop = $file->getProp();
  }

  /**
   * funkcja wczytujaca plik (dla CN - statycznej zmiany rozmiarow fotek
   * (w przyszlosci dorobic sprawdzanie podawanych warunkow!)
   *
   * @param string $post_file_name nazwa pola formularza
   *
   * @return array $file_prop - tablica danych dotyczacych uploadowanego pliku
   */
  function readFile($post_file_name, $dir = '') {

    if (!empty($dir)) {
      $this->img_dir_upl = $dir;
    }
    return $this->foto_prop = array(
      'name' => $post_file_name,
      'ext' => end(explode('.', $post_file_name)),
    );
  }

  /**
   * @param string $image_data
   * @param string $orig_name
   * @param string string $dir
   * @return array
   */
  function readBase64String($image_data, $orig_name, $dir = '') {

    if (!empty($dir)) {
      $this->img_dir_upl = $dir;
    }
    $orig_name = preg_replace("/[^a-zA-Z0-9-\.]/i", '', $orig_name);
    $ifp = fopen($this->img_dir_upl . $orig_name, "wb");
    fwrite($ifp, base64_decode($image_data));
    fclose($ifp);
    return $this->foto_prop = array(
      'name' => $orig_name,
      'ext' => end(explode('.', $orig_name)),
    );
  }

  /**
   * wczytanie plikow jpg
   *
   * @param file $NewImg
   * @param string $path_img
   *
   * @return bool
   */
  function imagejpeg_new($NewImg, $path_img) {

    if ($this->mime == 'image/jpeg' or $this->mime == 'image/pjpeg') {
      imagejpeg($NewImg, $path_img, $this->quality);
    } elseif ($this->mime == 'image/gif') {
      imagegif($NewImg, $path_img);
    } elseif ($this->mime == 'image/png') {
      imagepng($NewImg, $path_img);
    } else {
      return (false);
    }
    return (true);
  }

  function imagecreatefromjpeg_new($path_img) {

    if ($this->mime == 'image/jpeg' or $this->mime == 'image/pjpeg') {
      $OldImg = imagecreatefromjpeg($path_img);
    } elseif ($this->mime == 'image/gif') {
      $OldImg = imagecreatefromgif($path_img);
    } elseif ($this->mime == 'image/png') {
      $OldImg = imagecreatefrompng($path_img);
    } else {
      return (false);
    }
    return ($OldImg);
  }

  /**
   * funkcja do tworzenia miniaturek!
   * w tej wersji funkcji tworze 3 zdjecia:
   * foto_min = 64px;
   * foto_srednie = 120px; (lub 100)
   * foto_big = 230px;
   *
   * Uwaga, w zaleznosci od parametru (np zdefiniowanego width_max - dostowac dodana fotke)
   * waterInfo = info dla zrobienia watermarka
   * $waterInfo['add'] = true;           //adding watermark to image file
   * $waterInfo['waterMarkText'] = "copyrighted";//the text to draw as watermark
   * $waterInfo['font'] = "arial.ttf";   //font file to use for drawing text. need absolute path
   * $waterInfo['size'] = 10;       //font size
   * $waterInfo['angle'] = 45;       //angle to draw watermark text
   * $waterInfo['hSpacing'] = 120;     //horizontal spacing betweeen two sucessive watermark text
   * $waterInfo['vSpacing'] = 120;     //vertical spacing betweeen two sucessive watermark text
   * $waterInfo['shadow'] = false;     //if set to true then a shadow will be drawn under every watermark text
   *
   * @return err_no (zaimplementowac!):
   * -1 brak
   * 0 - ok
   * 1 - bad extension
   * 2 - bad sizes
   */
  function miniaturka($new_rozm_img, $name_new_foto, $waterInfo = array(), $waterInfoAdd = false) {

    //zmienne globalne z klasy uploadujacej
    $rozm_error_w = $this->max_width;
    $rozm_error_h = $this->max_height;
    $err_no = 0;
    $rozm_img = @getimagesize($this->img_dir_upl . $this->foto_prop['name']);
    if (($rozm_error_w > 0 and ($rozm_img[0] > $rozm_error_w)) or
        ($rozm_error_h > 0 and ($rozm_img[1] > $rozm_error_h))
    ) {
      @unlink($this->img_dir_upl . $this->foto_prop['name']);
      return false;
      //exit("Uploader: line 153, blad krytyczny: ".
      //"za duże rozmiary pliku (dopuszczalne wymiary: $rozm_error_w x $rozm_error_h)");
    }
    $ext = strtolower($this->foto_prop['ext']);
    $this->mime = $rozm_img['mime'];
    // +++++++++++++++++++++++++++++ wymiary fotek +++++++++++++++++++++++++++++
    // sprawdzam wymiary fotki, jesli dluzsza krawedz jest
    // mniejsza od wymaganej nic nie robie
    // UWAGA! zastanowic sie nad nazewnictwem pliku...
    if ($rozm_img[0] > $rozm_img[1]) {
      $dl_krawedz = $rozm_img[0];
    } else {
      $dl_krawedz = $rozm_img[1];
    }
    if (!in_array($ext, $this->imageExtentions)) {
      @unlink($this->dest_name);
      //exit("Uploader: line 165, blad krytyczny: ".
      //"zły format pliku, dopuszczalne typy: ". implode(', ', $this->imageExtentions));
      return false;
    } else {
      $file_img = $this->img_dir_upl . $this->foto_prop['name'];
      $file_min_img = $this->img_dir_upl . $name_new_foto . $this->foto_prop['name'];
      $src_img = $this->imagecreatefromjpeg_new($file_img);
      if ($src_img) {
        if ($dl_krawedz < $new_rozm_img) {
          $w = $rozm_img[0];
          $h = $rozm_img[1];
        } else {
          if ($rozm_img[0] > $rozm_img[1]) {
            $w = $new_rozm_img;
            $p = (imagesx($src_img) - $w) / imagesx($src_img);
            $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
          } else {
            $h = $new_rozm_img;
            $p = (imagesy($src_img) - $h) / imagesy($src_img);
            $w = imagesx($src_img) - floor(imagesx($src_img) * $p);
          }
        }
        if (($ext == 'jpg') || ($ext == 'jpeg')) {
          $dst_img = imagecreatetruecolor($new_rozm_img, $new_rozm_img);
          $back = imagecolorallocate($dst_img, 255, 255, 255);
          $border = imagecolorallocate($dst_img, 0, 0, 0);
          imagefilledrectangle($dst_img, 0, 0, $new_rozm_img - 1, $new_rozm_img - 1, $back);
        } else {
          $dst_img = imagecreate($new_rozm_img, $new_rozm_img);
          $white = imagecolorallocate($dst_img, 255, 255, 255);
        }
      } else {
        return false;
      }
      $x = (int)(($new_rozm_img - $w) / 2);
      $y = (int)(($new_rozm_img - $h) / 2);
      imagecopyresampled($dst_img, $src_img, $x, $y, 0, 0, $w, $h, $rozm_img[0], $rozm_img[1]);
      $this->imagejpeg_new($dst_img, $file_min_img, $this->quality);
      imagedestroy($src_img);
      imagedestroy($dst_img);
      if ($waterInfoAdd == true) {
        $this->addWaterMark($file_min_img, $ext, $name_new_foto, $waterInfo);
      }
    }
    return 0;
  }

  /**
   * dodaje watermark do obrazka
   *
   * @param string $file_img konkretny obrazek
   * @param string $ext      rozszerzenie
   * @param array $waterInfo info do watermarkowania, w przypadku null, korzysta z wlasnych obrazkow
   *
   * return img
   */
  function addWaterMark($file_img, $ext, $name_new_foto, $waterInfo = null) {

    $rozm_img = @getimagesize($file_img);
    $this->mime = $rozm_img['mime'];
    $src_img = $this->imagecreatefromjpeg_new($file_img);
    if (empty($waterInfo['waterMarkText'])) {
      return true;
    }
    //$waterInfo['waterMarkText'] = " ";
    if (empty($waterInfo['font'])) {
      $waterInfo['font'] = _MODELS . "verdana.ttf";
    }
    if (empty($waterInfo['size'])) {
      $waterInfo['size'] = 12;
    }
    if (empty($waterInfo['angle'])) {
      $waterInfo['angle'] = 20;
    }
    if (empty($waterInfo['hSpacing'])) {
      $waterInfo['hSpacing'] = 220;
    }
    if (empty($waterInfo['vSpacing'])) {
      $waterInfo['vSpacing'] = 220;
    }
    if (empty($waterInfo['shadow'])) {
      $waterInfo['shadow'] = false;
    }
    $grey = imagecolorallocate($src_img, 180, 180, 180); //color for watermark text
    $shadowColor = imagecolorallocate($src_img, 130, 130, 130); //color for shadow text
    for ($x_wm = 20; $x_wm < $rozm_img[0]; $x_wm += $waterInfo['hSpacing']) {
      for ($y_wm = -10; $y_wm < $rozm_img[1]; $y_wm += $waterInfo['vSpacing']) {
        if ($waterInfo['shadow']) {
          //draw shadow text over image
          imagettftext($src_img, $waterInfo['size'],
            $waterInfo['angle'], $x_wm + 1, $y_wm + 1, $shadowColor,
            $waterInfo['font'], $waterInfo['waterMarkText']);
        }
        imagettftext($src_img, $waterInfo['size'], $waterInfo['angle'],
          $x_wm, $y_wm, $grey, $waterInfo['font'], $waterInfo['waterMarkText']);
        //draw text over image
      }
    }
    $file_min_img = $this->img_dir_upl . $name_new_foto . $this->foto_prop['name'];
    $this->imagejpeg_new($src_img, $file_min_img, $this->quality);
    imagedestroy($src_img);
  }

  /**
   * tworzenie miniaturek proporcjonalnych do wymiarow oryginalnej fotki
   *
   * @param int $size             - nowy rozmiar (uwaga! w zaleznosci od krawedzi)
   * @param int $edge             - jesli auto, dluzsza krawedz zmieniam do size
   *                              jesli width || height - odpowiednio...
   * @param int $new_height       - nowy rozmiar (height)
   * @param string $name_new_foto - nazwa nowego obrazka
   *
   * @return err_no (zaimplementowac!):
   * -1 brak
   * 0 - ok
   * 1 - bad extension
   * 2 - bad sizes
   */
  function ratioMiniaturka($size = 0, $edge = 'auto', $name_new_foto, $waterInfo = array(), $waterInfoAdd = false) {

    $rozm_error_w = $this->max_width;
    $rozm_error_h = $this->max_height;
    $err_no = 0;
    $orig_size = false; //czy resize'owac zdjecia (jesli rozmiar < size)
    $rozm_img = @getimagesize($this->img_dir_upl . $this->foto_prop['name']);
    if (($rozm_error_w > 0 and ($rozm_img[0] > $rozm_error_w)) or
        ($rozm_error_h > 0 and ($rozm_img[1] > $rozm_error_h))
    ) {
      $err_no = 2;
      @unlink($this->img_dir_upl . $this->foto_prop['name']);
      return false;
      //exit("Uploader: line 336, blad krytyczny: ".
      //"za duże rozmiary pliku (dopuszczalne wymiary: $rozm_error_w x $rozm_error_h)");
    }
    $ext = strtolower($this->foto_prop['ext']);
    $this->mime = $rozm_img['mime'];
    if (!in_array($ext, $this->imageExtentions)) {
      $err_no = 1;
      @unlink($this->dest_name);
      return false;
      //exit("Uploader: line 343, blad krytyczny: ".
      //"zły format pliku, dopuszczalne typy: ". implode(', ', $this->imageExtentions));
    } else {
      $file_img = $this->img_dir_upl . $this->foto_prop['name'];
      $file_min_img = $this->img_dir_upl . $name_new_foto . $this->foto_prop['name'];
      $src_img = $this->imagecreatefromjpeg_new($file_img);
      #$src_img = imagecreatefromjpeg($file_img);
      if ($src_img) {
        /**
         * sprawdzam ktora krawedz jest dluzsza i ja zmniejsza (dla edge == auto)
         */
        switch ($edge) {
          case 'width':
            if ($rozm_img[0] > $size) {
              $w = $size;
              $p = (imagesx($src_img) - $w) / imagesx($src_img);
              $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
            } else {
              $orig_size = true;
            }
            break;
          case 'height':
            if ($rozm_img[1] > $size) {
              $h = $size;
              $p = (imagesy($src_img) - $h) / imagesy($src_img);
              $w = imagesx($src_img) - floor(imagesx($src_img) * $p);
            } else {
              $orig_size = true;
            }
            break;
          case 'okladka':
            // na potrzeby nistadndardow wprowadzilem nowa opcja
            if ($rozm_img[0] < $rozm_img[1]) {
              $w = $size / 2;
            } else {
              $w = $size;
            }
            $p = (imagesx($src_img) - $w) / imagesx($src_img);
            $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
            break;
          default:
            if ($rozm_img[0] > $rozm_img[1]) {
              if ($rozm_img[0] > $size) {
                $w = $size;
                $p = (imagesx($src_img) - $w) / imagesx($src_img);
                $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
              } else {
                $orig_size = true;
              }
            } else {
              if ($rozm_img[1] > $size) {
                $h = $size;
                $p = (imagesy($src_img) - $h) / imagesy($src_img);
                $w = imagesx($src_img) - floor(imagesx($src_img) * $p);
              } else {
                $orig_size = true;
              }
            }
            break;
        }
        if ($orig_size === true) {
          $w = $rozm_img[0];
          $h = $rozm_img[1];
        }
        if (($ext == 'jpg') || ($ext == 'jpeg')) {
          $dst_img = imagecreatetruecolor($w, $h);
          $back = imagecolorallocate($dst_img, 255, 255, 255);
          $border = imagecolorallocate($dst_img, 0, 0, 0);
          imagefilledrectangle($dst_img, 0, 0, $w - 1, $h - 1, $back);
        } else {
          $dst_img = imagecreate($w, $h);
          $white = imagecolorallocate($dst_img, 255, 255, 255);
        }
      }
      $dest_width = $w;
      $dest_height = $h;
      $src_width = $rozm_img[0];
      $src_height = $rozm_img[1];
      imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
      $this->imagejpeg_new($dst_img, $file_min_img, $this->quality);
      imagedestroy($src_img);
      imagedestroy($dst_img);
      if ($waterInfoAdd == true) {
        $this->addWaterMark($file_min_img, $ext, $name_new_foto, $waterInfo);
      }
    }
    return $err_no;
  }

  /**
   * nowa funkcja do tworzenia dowolnych miniaturek
   *
   * @param int $NewWidth
   * @param int $NewHeight
   * @param string $name_new_foto
   * @param array $waterInfo
   * @param bool $waterInfoAdd
   *
   * @return bool?
   */
  function ratioMiniaturkaNew($NewWidth = 0, $NewHeight = 0, $name_new_foto, $waterInfo = array(), $waterInfoAdd = false) {

    $rozm_error_w = $this->max_width;
    $rozm_error_h = $this->max_height;
    $err_no = 0;
    $orig_size = false; //czy resize'owac zdjecia (jesli rozmiar < size)
    $file_img = $this->img_dir_upl . $this->foto_prop['name'];
    $file_min_img = $this->img_dir_upl . $name_new_foto . $this->foto_prop['name'];
    $Oldsize = @getimagesize($file_img);
    $this->mime = $Oldsize['mime'];
    $OldWidth = $Oldsize[0];
    $OldHeight = $Oldsize[1];
    $ext = strtolower($this->foto_prop['ext']);
    if (($OldWidth > $rozm_error_w) || ($OldHeight > $rozm_error_h)) {
      $err_no = 2;
      @unlink($this->img_dir_upl . $this->foto_prop['name']);
      return false;
      //exit("Uploader: line 482, blad krytyczny: ".
      //"za duże rozmiary pliku (dopuszczalne wymiary: $rozm_error_w x $rozm_error_h)");
    }
    if (!in_array($ext, $this->imageExtentions)) {
      $err_no = 1;
      @unlink($this->dest_name);
      return false;
      //exit("Uploader: line 491, blad krytyczny: ".
      //"zły format pliku, dopuszczalne typy: ". implode(', ', $this->imageExtentions));
    } else {
      if ($NewHeight == '' and $NewWidth != '') {
        $NewHeight = ceil(($OldHeight * $NewWidth) / $OldWidth);
      } elseif ($NewWidth == '' and $NewHeight != '') {
        $NewWidth = ceil(($OldWidth * $NewHeight) / $OldHeight);
      } elseif ($NewHeight == '' and $NewWidth == '') {
        return (false);
      }
      $OldHeight_castr = ceil(($OldWidth * $NewHeight) / $NewWidth);
      $castr_bottom = ($OldHeight - $OldHeight_castr) / 2;
      $OldWidth_castr = ceil(($OldHeight * $NewWidth) / $NewHeight);
      $castr_right = ($OldWidth - $OldWidth_castr) / 2;
      if ($castr_bottom > 0) {
        $OldWidth_castr = $OldWidth;
        $castr_right = 0;
      } elseif ($castr_right > 0) {
        $OldHeight_castr = $OldHeight;
        $castr_bottom = 0;
      } else {
        $OldWidth_castr = $OldWidth;
        $OldHeight_castr = $OldHeight;
        $castr_right = 0;
        $castr_bottom = 0;
      }
      $OldImg = $this->imagecreatefromjpeg_new($file_img);
      if ($OldImg) {
        $NewImg_castr = imagecreatetruecolor($OldWidth_castr, $OldHeight_castr);
        if ($NewImg_castr) {
          //jesli chcesz zachowac proporcje
          //imagecopyresampled($NewImg_castr, $OldImg, 0, 0, $castr_right, $castr_bottom,
          imagecopyresampled($NewImg_castr, $OldImg, 0, 0, 0, 0,
            $OldWidth_castr, $OldHeight_castr, $OldWidth_castr, $OldHeight_castr);
          $NewImg = imagecreatetruecolor($NewWidth, $NewHeight);
          if ($NewImg) {
            imagecopyresampled($NewImg, $NewImg_castr, 0, 0, 0, 0, $NewWidth,
              $NewHeight, $OldWidth_castr, $OldHeight_castr);
            imagedestroy($NewImg_castr);
            imagedestroy($OldImg);
            if (!$this->imagejpeg_new($NewImg, $file_min_img, $this->quality)) {
              return (false);
            }
            imagedestroy($NewImg);
          }
        }
      } else {
        return false;
      }
    }
    return true;
  }

  /**
   * nowa funkcja do tworzenia dowolnych miniaturek
   *
   * @param int $NewWidth
   * @param int $NewHeight
   * @param string $name_new_foto
   * @param array $waterInfo
   * @param bool $waterInfoAdd
   * @return bool?
   */
  function ratioMiniaturkaNew2($NewWidth = 0, $NewHeight = 0, $name_new_foto, $path = '', $waterInfo = array(), $waterInfoAdd = false) {

    $rozm_error_w = $this->max_width;
    $rozm_error_h = $this->max_height;
    $err_no = 0;
    $orig_size = false; //czy resize'owac zdjecia (jesli rozmiar < size)
    if (!empty($path)) {
      $file_img = $path . $this->foto_prop['name'];
    } else {
      $file_img = $this->img_dir_upl . $this->foto_prop['name'];
    }
    $file_min_img = $this->img_dir_upl . $name_new_foto . $this->foto_prop['name'];
    if (!is_file($file_img)) {
      exit('brak pliku <!-- ' . $file_img . ' -->');
    }
    $rozm_img = @getimagesize($file_img);
    $this->mime = $rozm_img['mime'];
    $ext = strtolower($this->foto_prop['ext']);
    if (($rozm_error_w > 0 and ($rozm_img[0] > $rozm_error_w)) or
        ($rozm_error_h > 0 and ($rozm_img[1] > $rozm_error_h))
    ) {
      $err_no = 2;
      @unlink($this->img_dir_upl . $this->foto_prop['name']);
      return false;
      //exit("Uploader: line 336, blad krytyczny: ".
      //"za duże rozmiary pliku (dopuszczalne wymiary: $rozm_error_w x $rozm_error_h)");
    }
    if (!in_array($ext, $this->imageExtentions)) {
      $err_no = 1;
      @unlink($this->dest_name);
      return false;
      //exit("Uploader: line 491, blad krytyczny: ".
      //"zły format pliku, dopuszczalne typy: ". implode(', ', $this->imageExtentions));
    } else {
      //--------------------
      $src_img = $this->imagecreatefromjpeg_new($file_img);
      if ($rozm_img[0] > $rozm_img[1]) {
        if ($rozm_img[0] > $NewWidth) {
          $w = $NewWidth;
          $p = (imagesx($src_img) - $w) / imagesx($src_img);
          $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
        } else {
          $orig_size = true;
        }
      } else {
        if ($rozm_img[1] > $NewHeight) {
          $h = $NewHeight;
          $p = (imagesy($src_img) - $h) / imagesy($src_img);
          $w = imagesx($src_img) - floor(imagesx($src_img) * $p);
        } else {
          $orig_size = true;
        }
      }
      if ($orig_size === true) {
        $w = $rozm_img[0];
        $h = $rozm_img[1];
      }
      if (($ext == 'jpg') || ($ext == 'jpeg')) {
        $dst_img = imagecreatetruecolor($w, $h);
        $back = imagecolorallocate($dst_img, 255, 255, 255);
        $border = imagecolorallocate($dst_img, 0, 0, 0);
        imagefilledrectangle($dst_img, 0, 0, $w - 1, $h - 1, $back);
      } else {
        $dst_img = imagecreate($w, $h);
        $white = imagecolorallocate($dst_img, 255, 255, 255);
      }
      $dest_width = $w;
      $dest_height = $h;
      $src_width = $rozm_img[0];
      $src_height = $rozm_img[1];
      imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
      $this->imagejpeg_new($dst_img, $file_min_img, $this->quality);
      imagedestroy($src_img);
      imagedestroy($dst_img);
      if ($waterInfoAdd == true) {
        $this->addWaterMark($file_min_img, $ext, $name_new_foto, $waterInfo);
      }
    }
    return $err_no;
  }

  /**
   * sciaga obrazek z zewnetrznego serwera i zapisuje na serwer
   *
   * @param string $imgurl
   * @param string $dir
   * @param string $picture_name
   * @param bool $wget
   *
   * @return bool
   */
  function downloadImage($imgurl, $dir = false, $picture_name = false, $wget = false) {

    if (!empty($dir)) {
      $this->img_dir_upl = $dir;
    }
    if (!is_dir($this->img_dir_upl)) {
      mkdir($this->img_dir_upl, 0775);
    }
    //$tmp_file = $this->setName();
    //$this->img_dir_upl.
    chdir($this->img_dir_upl);
    $this->_seeded = 0;
    $tmp_file = HTTP_Upload_File::nameToUniq();
    if (function_exists('curl_init') and $wget == false) { // check for CURL, if not use fopen
      $curl = curl_init();
      $localimage = fopen($tmp_file, "wb");
      curl_setopt($curl, CURLOPT_URL, $imgurl);
      curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 1);
      curl_setopt($curl, CURLOPT_BINARYTRANSFER, 1);
      curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
      curl_setopt($curl, CURLOPT_FILE, $localimage);
      curl_exec($curl);
      curl_close($curl);
      fclose($localimage);
    } else {
      $localimage = $this->img_dir_upl . $picture_name;
      $cmd = "wget -O $tmp_file $imgurl";
      system($cmd);
      //          $filedata = "";
      //      $remoteimage = fopen($imgurl, 'rb');
      //      if ($remoteimage) {
      //        while(!feof($remoteimage)) {
      //          $filedata.= fread($remoteimage,1024*8);
      //        }
      //      }
      //      fclose($remoteimage);
      //      $localimage = fopen($tmp_file, 'wb');
      //      fwrite($localimage, $filedata);
      //      fclose($localimage);
      copy($tmp_file, $localimage);
    } // end CURL check
    //chmod ($tmp_file, 0666);
    if (is_file($tmp_file)) {
      $a_img_type = getimagesize($tmp_file);
      if (is_array($a_img_type)) {
        $mime = $a_img_type['mime'];
        switch ($mime) {
          case 'image/gif':
            $ext = '.gif';
            break;
          case 'image/png':
            $ext = '.png';
            break;
          case 'image/x-png':
            $ext = '.png';
            break;
          case 'image/jpeg' || 'image/jpg' :
            $ext = '.jpg';
            break;
          default:
            $ext = '.tmp';
            break;
        }
        if (empty($picture_name)) {
          $picture_name = $tmp_file . $ext;
        }
        rename($tmp_file, $picture_name);
        return $this->readFile($picture_name);
        //return $tmp_file.$ext;
      }
    }
    return false;
  }

  function moveFile($source_file, $dest_file, $move = true) {

    if ($move) {
      rename($this->img_dir_upl . $source_file, $dest_file);
    } else {
      copy($this->img_dir_upl . $source_file, $dest_file);
    }
  }

  /**
   * funkcja dodaje do katalogu prefix katalogu wg nowego systemu
   * @param $id
   */
  function uploadDirById($id) {

    $dir = round($id/10000);
    $sub_dir = round($id/1000);

    if (!is_dir($this->img_dir_upl . $dir)) {
      mkdir($this->img_dir_upl . $dir, 0755);
    }
    $this->img_dir_upl .= $dir . '/';
    if (!is_dir($this->img_dir_upl . $sub_dir)) {
      mkdir($this->img_dir_upl . $sub_dir, 0755);
    }
    $this->img_dir_upl .= $sub_dir . '/';
    if (!is_dir($this->img_dir_upl . $id)) {
      mkdir($this->img_dir_upl . $id, 0755);
    }
    $this->img_dir_upl .= $id . '/';
  }
}