<?php

class Categories extends AdminEngine {
  function __construct() {
    parent::__construct();
  }

  /**
   * pobranie kategorii-dzieci wg parent_id
   *
   * @param int $parent
   * @param bool $show_refresh
   * @return string
   */
  function getCategoriesByParent($parent) {

    //sprawdzanie parentow (czasami pierwszy jest pusty...
    $a_parents = explode(',', $parent);
    if (isset($a_parents[0]) and $a_parents[0] != '') {
      $parent = $a_parents[0];
    } elseif (isset($a_parents[1]) and $a_parents[1] != '') {
      $parent = $a_parents[1];
    } else {
      return $parents;
    }
    $parent_category = $this->getCategory($parent);
    $res = $this->getCategories($parent);
    $js_content = array();
    if (!empty($res)) {
      $js_content = $this->buildJsContent($res, $parent_category);
    }
    return json_encode($js_content);
  }

  function getCategories($parent) {

    return $this->selectAll('categories', array('no_uid' => true, 'parent_id' => (int)$parent), '*', "AND kolejnosc <> '-1' ORDER BY lewel");
  }

  function getAllCategories() {
    return $this->selectAll('categories', array('no_uid' => true, 'parent_id' => (int)$parent), '*', "AND kolejnosc <> '-1' ORDER BY lewel");
  }
  /**
   * funkcja zwraca tablice kategori i dzieci dla js
   *
   * @param array $a_data
   * @param int $parent
   * @return string
   *
   */
  function buildJsContent($a_data, $parent_cat) {

    $children = array();
    $parent = array(
      'id' => $parent_cat['id'],
      'name' => $parent_cat['name']
    );
    if (!empty($a_data)) {
      foreach ($a_data as $value) {
        $children[] = array(
          'id' => $value['id'],
          'name' => $value['name'],
          'childsCount' => $value['cnt_cat'],
        );
      }
    }
    $parent['children'] = $children;
    return $parent;
  }

  /**
   * pobranie kategorii wg parenta i stworzenie stringu js
   *
   * @param int $kat_id
   * @return string $js_content
   */
  function getParentsByCategory($kat_id) {

//    $js_content = '';
//    $js_content .= "parents[0] = 0;";
    $js_content = $this->getParents($kat_id);
//    $js_content .= 'RefreshAll();';
    return $js_content;
  }

  /**
   * rekursywne pobieranie parentow danej kategorii
   *
   * @param int $kat_id
   *
   * @return string $js_content
   *
   */
  function getParents($kat_id) {

    global $a_parents_id;
    if (!isset($a_parents_id)) {
      $a_parents_id = array();
    }
    $kat_id = (int)$kat_id;
    if ($kat_id > 0) {
      $res = $this->selectQuery('categories', 'row', array('no_uid' => true, 'id' => $kat_id));
      $a_parents_id[] = $res['id'];
      return $this->getParents($res['parent_id']);
    } else {
      if (!empty($a_parents_id)) {
        $a_parents = array_reverse($a_parents_id);
        unset($a_parents_id);
      }
      $js_content = '';
      $j = 1;
      if (is_array($a_parents)) {
        foreach ($a_parents as $value) {
          $js_content .= "parents[$j] = {$value};";
          $js_content .= $this->getCategoriesByParent($value, false);
          ++$j;
        }
      }
      if ($j > 4) {
        $offset = ($j - 3);
      } else {
        $offset = 0;
      }
      $js_content .= "offset=$offset;";
      return $js_content;
    }
  }

  /**
   * pobranie kategorii-dzieci dla swistak.pl wg parent_id
   *
   * @param int $parent
   * @param bool $show_refresh
   * @return string
   */
  function getSwistakCategoriesByParent($parent, $show_refresh = true) {

    //sprawdzanie parentow (czasami pierwszy jest pusty...
    $a_parents = explode(',', $parent);
    if (isset($a_parents[0]) and $a_parents[0] != '') {
      $parent = $a_parents[0];
    } elseif (isset($a_parents[1]) and $a_parents[1] != '') {
      $parent = $a_parents[1];
    } else {
      return $parents;
    }
    $res = $this->selectLeft('categories', 'swistak_cats', 'swistak_cats.id=categories.id',
      'categories.*, swistak_cats.swistak_id', array('categories.parent_id' => (int)$parent),
      'ORDER BY categories.lewel ASC');
    $js_content = '';
    if (!empty($res)) {
      $js_content = $this->buildJsContent($res, $parent);
      if ($show_refresh == true) {
        $js_content .= 'RefreshAll();';
      }
    }
    return $js_content;
  }

  /**
   * pobranie kategorii wg parenta i stworzenie stringu js
   *
   * @param int $kat_id
   * @return string $js_content
   */
  function getSwistakParentsByCategory($kat_id) {

    $js_content = '';
    $js_content .= "parents[0] = 0;";
    $js_content .= $this->getSwistakParents($kat_id);
    $js_content .= 'RefreshAll();';
    return $js_content;
  }

  /**
   * rekursywne pobieranie parentow danej kategorii
   *
   * @param int $kat_id
   *
   * @return string $js_content
   *
   */
  function getSwistakParents($kat_id) {

    global $a_parents_id;
    if (!isset($a_parents_id)) {
      $a_parents_id = array();
    }
    //todo sprawdzić działanie tej funkcji!
    $kat_id = (int)$kat_id;
    if ($kat_id > 0) {
      $a_ph = array($kat_id);
      $q = "SELECT c.id AS id, c.parent_id, c.parents_id, s.swistak_id FROM {$this->TABLES['categories']} c " .
          "JOIN {$this->TABLES['swistak_cats']} s ON c.id=s.id  WHERE c.id=?";
      $res = $this->dbh->getRow($q, null, $a_ph);
      errorSql($res);
      $a_parents_id[] = $res['id'];
      return $this->getParents($res['parent_id']);
    } else {
      if (!empty($a_parents_id)) {
        $a_parents = array_reverse($a_parents_id);
        unset($a_parents_id);
      }
      $js_content = '';
      $j = 1;
      if (is_array($a_parents)) {
        foreach ($a_parents as $value) {
          $js_content .= "parents[$j] = {$value};";
          $js_content .= $this->getCategoriesByParent($value, false);
          ++$j;
        }
      }
      if ($j > 4) {
        $offset = ($j - 3);
      } else {
        $offset = 0;
      }
      $js_content .= "offset=$offset;";
      return $js_content;
    }
  }

  /**
   * pobranie wybranej kategorii
   *
   * @param int $catId
   * @return string $res
   */
  public function getCategory($catId) {

    return $this->selectQuery('categories', 'row', array('no_uid' => true, 'id' => (int)$catId));
  }

  public function getMainCategories($json_encode = true) {

    $res = $this->getCategories(0);
    if ($json_encode == false) {
      return $res;
    }
    $categories = array();
    foreach ($res as $value) {
      $categories[] = array(
        'id' => $value['id'],
        'is_leaf' => 0,
        'position' => 0,
        'name' => $value['name'],
      );
    }
    return json_encode($categories);
  }

  /*public function getParentCategories($kat_id) {

    global $a_parents_id;
    if (!isset($a_parents_id)) {
      $a_parents_id = array();
    }
    $kat_id = (int)$kat_id;
    if ($kat_id > 0) {
      $res = $this->selectQuery('categories', 'row', array('no_uid' => true, 'id' => $kat_id));
      $a_parents_id[] = $res['id'];
      return $this->getParents($res['parent_id']);
    } else {
      if (!empty($a_parents_id)) {
        $a_parents = array_reverse($a_parents_id);
        unset($a_parents_id);
      }
      $js_content = '';
      $j = 1;
      if (is_array($a_parents)) {
        foreach ($a_parents as $value) {
          $js_content .= "parents[$j] = {$value};";
          $js_content .= $this->getCategoriesByParent($value, false);
          ++$j;
        }
      }
      if ($j > 4) {
        $offset = ($j - 3);
      } else {
        $offset = 0;
      }
      $js_content .= "offset=$offset;";
      return $js_content;
    }
  }*/

  function getAllParents($parent) {

    global $all_parents;
    if (!isset($all_parents)) {
      $all_parents = array();
    }
    if ($parent > 0) {
      $res = $this->getCategories($parent);
      $all_parents[] = $res;
      //pobranie rodzica
      $parent_cat = $this->getCategory($parent);
      return $this->getAllParents($parent_cat['parent_id']);
    } else {
      $all_parents[] = $this->getCategories(0);
      return array_reverse($all_parents);
    }
  }

  function getParentsByCategoryId($id) {

    $category = $this->getCategory($id);
    $all_parents = $this->getAllParents($category['parent_id']);
    $js_parents = array();
    $i = 0;
    foreach ($all_parents as $parents) {
      if ($i < 2) {
        $prev_parent = 0;
      } else {
        $prev_parent = $all_parents[$i-1][0]['parent_id'];
      }
      $i += 1;
      $js_sub_parents = array();
      foreach ($parents as $parent) {
        $js_sub_parents[] = array(
          'id' => $parent['id'],
          'name' => $parent['name'],
          'parent_id' => $parent['parent_id'],
          'prevParent' => $prev_parent,
          'childsCount' => $parent['cnt_cat'],
        );
      }
      $js_parents[] = $js_sub_parents;
    }
    return json_encode($js_parents);
  }

  /**
   * wypisywanie kategorii
   *
   * @param int $pozycja
   * @param int $id_parenta
   * @return string?
   */
  function createCatsArray($pozycja, $id_parenta, $categories) {

    global $iteracja, $a_iter_cats;
    $cnt = count($categories);

    if (!isset($a_iter_cats)) {
      $a_iter_cats = array();
    }
    if (!isset($iteracja)) {
      $iteracja = 1;
    }
    $iteracja_prv = 1;
    for ($i = $pozycja; $i < $cnt; $i++) {
      if ($categories[$i]['parent'] == $id_parenta) {
        if (!isset($margin)) {
          $margin = '';
        }
        for ($j = 1; $j < $iteracja; $j++) {
          $margin .= '- ';
        }
        if ($categories[$i]['parent'] == 0) {
          $kat_name = $categories[$i]['name'];
        } else {
          $kat_name = '|' . $margin . $categories[$i]['name'];
        }
        $a_iter_cats[$categories[$i]['id']] = $kat_name;
        unset($margin);
        // +++++++++++++++++++++++++++++ /to_do
        $iteracja += $iteracja_prv;
        $this->createCatsArray($i + 1, $categories[$i]['id'], $categories);
      }
    }
    $iteracja -= $iteracja_prv;
    return $a_iter_cats;
  }

}
