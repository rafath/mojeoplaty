<?php

class SliderImage extends AdminEngine {

  function __construct() {

    parent::__construct();
  }

  /**
   *
   * @return array
   */
  public function findAll($slider_id) {

    return $this->selectAll('slider_images', array('slider_id'=> $slider_id), '*', 'order by sorter');
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array
   */
  public function find($id) {

    return $this->selectRow('slider_images', $id);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return mixed
   */
  public function create($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'slider_id' => (int)$slider_id,
      'sorter' => (int)$sorter,
      'image' => $image,
      'title' => $title,
      'description' => $description,
    );
    return $this->autoInsertQuery('slider_images', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  public function update($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);

    if (isset($old_image)) {
          $image = $this->setPicture(2, $old_image, $image, isset($del_photo));
        } else {
          $image = '';
        }

    $fields = array(
      'slider_id' => (int)$slider_id,
      'sorter' => (int)$sorter,
      'image' => $image,
      'title' => $title,
      'description' => $description,
    );
    return $this->autoUpdateQuery('slider_images', $fields, $id);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  public function delete($id) {

    return $this->autoDeleteQuery('slider_images', $id);
  }
}
