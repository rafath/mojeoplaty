<?php
/*
 * defined in config
define ("ADM_MIN", '60x60');
define ("ADM_MED", '100x100');
define ("PAS_MED", '200x250');
define ("PAS_MAX", '300x300');
define ("CMS_MED", '160x220');
define ("CMS_MAX", '300x380');
define ("SHP_MIN", '50x50');
define ("SHP_MED", '200x260');
define ("SHP_MAX", '300x300');*/
//prefixes: adm_ZZxYY_name, pas_ZZxYY_name, shp_ZZxYY_name, cms_ZZxYY_name
//extends ImageUpload
class FileUpload {
  public $_files; //$_FILES: name, type, size, tmp_name,
  public $_file; //one file from _files array (by field_name)
  public $_dir; //shop (main) upload dir
  public $img_dir_upl; //destination dir of file
  public $uploaded_file = array(); //uploaded file info
  public $max_width = 5001;
  public $max_height = 5001;
  public $quality = 90;
  public $error = null;
  public $image_size = array();
  public $name_mode = 'uniq'; //safe
  private $_seeded = 0;
  private $_chmod = 0755;

  public $imageExtentions = array('jpg', 'gif', 'jpeg', 'png', 'x-png', 'swf', 'psd'); //'tif', 'zip'
  public $soundExtentions = array('wav', 'mp3', 'midi');
  //public $videoExtentions = array('wmv', 'asf', 'avi');
  public $videoExtentions = array();
  public $docExtentions = array('pdf', 'doc', 'txt', 'rtf', 'xls', 'csv', 'docx', 'xlsx', 'zip', 'tgz', 'gz', 'mp3');
  public $registered_types = array(
    "application/x-gzip-compressed" => ".tar.gz, .tgz",
    "application/x-zip-compressed" => ".zip",
    "application/zip" => ".zip",
    "application/x-tar" => ".tar",
    //"text/plain" => ".html, .php, .txt, .inc (etc)",
    "text/plain" => ".txt",
    "text/xml" => ".xml",
    //"image/bmp" => ".bmp, .ico",
    "audio/mpeg" => ".mp3",
    "image/gif" => ".gif",
    "image/pjpeg" => ".jpg, .jpeg",
    "image/jpeg" => ".jpg, .jpeg",
    "image/x-png" => ".png",
    "image/png" => ".png",
    'image/psd' => ".psd",
    'image/vnd.adobe.photoshop' => ".psd",
    'image/tiff' => ".tif",
    "application/x-shockwave-flash" => ".swf",
    "application/msword" => ".doc",
    "application/pdf" => ".pdf",
    "application/vnd.ms-excel" => ".xls",
    "text/css" => ".css",
    "application/octet-stream" => ".exe, .fla, .csv",
    "application/csv" => ".csv",
    "text/csv" => ".csv",
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => '.xlsx',
  );
  public $allowed_types = array(
    //"image/bmp",
    "image/gif",
    "image/pjpeg",
    "image/jpeg",
    "image/x-png",
    "image/png",
    "audio/mpeg",
    "application/msword",
    "application/pdf",
    "application/zip",
    "text/css",
    "text/plain",
    "application/x-zip-compressed",
    "application/x-shockwave-flash",
    "application/vnd.ms-excel",
    "application/octet-stream",
    "application/csv",
    'image/tiff',
    "text/xml",
    "text/csv",
    'image/vnd.adobe.photoshop',
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  );
  public $imgmimetype = array(
    "image/gif",
    "image/pjpeg",
    "image/jpeg",
    "image/x-png",
    "image/png",
    'image/gif',
    'application/x-shockwave-flash',
    'image/psd',
    'image/vnd.adobe.photoshop',
    'image/bmp',
    'image/tiff',
    'application/octet-stream',
    'image/jp2',
    'application/x-shockwave-flash',
    'image/vnd.wap.wbmp',
    //'image/xbm'
  );
  private $a_exceptions = array(
    0 => 'success',
    1 => 'failed',
    2 => 'Given field_name does not exist {name}',
    3 => 'File size is too large',
    4 => 'File width and height is too big',
    5 => 'File extension is incorrect {name}',
    6 => 'File mime type is incorrect',
    7 => 'Cant move uploaded file {name}',
    8 => 'Wrong size of image {name}',
    9 => 'squareImage -> src_img not defined',
    10 => 'ratioImage -> src_img not defined',
    11 => 'Cant move uploaded file {name}',
    12 => 'Given file is not an image {name}',
    13 => 'FileForm is empty',
  );

  function __construct($FILES = array(), $_dir = null) {

    if (!empty($_FILES)) {
      $this->postFiles($FILES);
    }
    $this->_dir = (!empty($_dir)) ? $_dir : IMG_UPL;
  }

  function postFiles($FILES) {

    $this->_files = $FILES;
  }

  /**
   * @param $file_field name of field
   * @param int || string $id - record number
   * @param string $img_type product || cms || file || url || base64?
   * @param string $type mime type
   */
  function setUploadedFile($file_field, $id = 0, $img_type = 'article', $type = 'image') {

    switch ($img_type) {
      case 'article':
        if ($this->checkFileConditions($file_field, $type) === true) {
          $this->setUploadDir($id);
          $this->uploadProductImage();
        }
        break;
      case 'page':
        if ($this->checkFileConditions($file_field, $type) === true) {
          $this->setUploadDir($id);
          $this->uploadProducerImage();
        }
        break;
      case 'video':
        if ($this->checkFileConditions($file_field, $type) === true) {
          $this->setUploadDir($id);
          $this->uploadCmsImage();
        }
        break;
      case 'slider':
        if ($this->checkFileConditions($file_field, $type) === true) {
          $this->setUploadDir($id);
          $this->uploadSliderImage();
        }
        break;
      case 'file':
        //przypisz do _file!
        $this->uploadSimpleFile($id, $file_field, $type);
        break;
      default:
    }
    return isset($this->uploaded_file['name']) ? $this->uploaded_file['name'] : null;
  }

  function simpleUploadFile($file_field, $dir, $type = 'image') {

    $this->img_dir_upl = $dir;
    if ($this->checkFileConditions($file_field, $type) === true) {
      $this->prepareUploadedFile();
//      if (preg_match('/image/', $this->_file['type'])) {
//        $this->prepareUploadedFile();
//        $this->createPicture(ADM_MIN);
//        $this->createPicture(ADM_MED);
//      }
      return $this->uploaded_file;
    }
    return false;
  }

  function checkFileConditions($file_field, $type) {

    if (!isset($this->_files[$file_field])) {
      $error = 3;
    }
    if (empty($this->_files[$file_field]['tmp_name'])) {
      return false;
      $error = 13;
    } else {
      $this->_file = $this->_files[$file_field];
      $file_info = explode('.', $this->_file['name']);
      $this->_file['ext'] = strtolower(end($file_info));
//      if ($type == 'image') {
      if ($type == 'image' and preg_match('/image|flash/', $this->_file['type'])) {
        $this->image_size = getimagesize($this->_file['tmp_name']);
        if (($this->image_size[0] > $this->max_width) || ($this->image_size[1] > $this->max_height)) {
          $error = 4;
        }
      }
      if (!isset($error)) {
        $error = $this->checkExtension($type);
      }
    }
    if (is_int($error)) {
      //if is error - delete file
      @unlink($this->_file['tmp_name']);
      $this->setException($error, $file_field);
    }
    return $error;
  }

  function checkExtension($type) {

    switch ($type) {
      case 'sound':
        $allowed_ext = $this->soundExtentions;
        break;
      case 'video':
        $allowed_ext = $this->videoExtentions;
        break;
      case 'doc':
        $allowed_ext = $this->docExtentions;
        break;
      case 'all':
        $allowed_ext = array_merge($this->imageExtentions, $this->soundExtentions,
          $this->videoExtentions, $this->docExtentions);
        break;
      default:
        $allowed_ext = $this->imageExtentions;
        break;
    }
    if (!in_array($this->_file['ext'], $allowed_ext)) {
      return 5;
    }
    if (!in_array($this->_file['type'], $this->allowed_types)) {
      return 6;
    }
    return true;
  }

  private function setException($id, $name = false) {

    if (!empty($name)) {
      $this->a_exceptions[$id] = preg_replace('/{name}/', $name, $this->a_exceptions[$id]);
    }
    error_log($this->a_exceptions[$id]);
//    $this->logApiRequests(0, 0, 'exception', $this->a_exceptions[$id]);
    $this->error = array('faultString' => $this->a_exceptions[$id], 'faultCode' => $id);
  }

  /**
   * funkcja dodaje do katalogu prefix katalogu wg nowego systemu
   * @param $id
   */
  function setUploadDir($id) {

    if ($id > 0) {
      if (!is_dir($this->_dir . $id)) {
        mkdir($this->_dir . $id, 0775);
        umask(0002);
      }
      $this->img_dir_upl = $this->_dir . $id . '/';
      //echo $this->img_dir_upl;
    } else {
      $this->img_dir_upl = $this->_dir;
    }
  }

  /*  private function logApiRequests($user_id, $shop_id, $operation, $request = null, $session_id = null) {

      $fields = array(
        'no_uid' => true,
        'user_id' => $user_id,
        'shop_id' => $shop_id,
        'operation' => $operation,
        'parametrs' => $request,
        'ip' => $this->getIp(),
        'session_id' => $session_id,
      );
      $this->autoInsertQuery('api_log', $fields);
    }*/
  /**
   * scenario:
   * upload images for product (with prefix and proper sizes) adm and shp and pas
   * for shp - taking info from shop_settings other info for adm and pas - takes from config
   */
  private function prepareUploadedFile() {

    $this->uploaded_file = $this->_file;
    $this->uploaded_file['name'] = $this->setFileName();
    $this->uploaded_file['file_path'] = $this->img_dir_upl . $this->uploaded_file['name'];
    if (!move_uploaded_file($this->_file['tmp_name'], $this->uploaded_file['file_path'])) {
      $this->setException(7, $this->uploaded_file['file_path']);
      return false;
    }
    chmod($this->uploaded_file['file_path'], $this->_chmod);
    return true;
  }

  function prepareLocalFile($file_name, $dir, $id) {

    if (is_file($dir . $file_name)) {
      $ext = strtolower(end(explode('.', $file_name)));
      if (!in_array($ext, $this->imageExtentions)) {
        $this->setException(5, $ext);
        return false;
      }
      $this->image_size = getimagesize($dir . $file_name);
      $this->uploaded_file['ext'] = $ext;
      $this->uploaded_file['name'] = $file_name;
      $this->uploaded_file['type'] = $this->image_size['mime'];
      $this->setUploadDir($id);
      $this->uploaded_file['file_path'] = $this->img_dir_upl . $this->uploaded_file['name'];
    }
    if ($dir != $this->img_dir_upl) {
      copy($dir . $file_name, $this->uploaded_file['file_path']);
    }
    return true;
  }

  function prepareRemoteFile($url_file, $id) {

    $this->setUploadDir($id);
    $img_info = $this->downloadImage($url_file);
    if (!empty($img_info)) {
      $this->uploaded_file['ext'] = $img_info['ext'];
      $this->uploaded_file['name'] = $img_info['name'];
      $this->uploaded_file['type'] = $this->image_size['mime'];
      $this->uploaded_file['file_path'] = $this->img_dir_upl . $this->uploaded_file['name'];
    } else {
      return false;
    }
    return true;
  }

  function prepare64string($image_data, $id) {

    $this->setUploadDir($id);
    $img_name = $this->setFileName(false);
    $localimage = $this->img_dir_upl . $img_name;
    $fp = fopen($localimage, "wb");
    fwrite($fp, base64_decode($image_data));
    fclose($fp);
    $img_info = $this->isImage($img_name, $localimage, 'base64');
    if (!empty($img_info)) {
      $this->uploaded_file['ext'] = $img_info['ext'];
      $this->uploaded_file['name'] = $img_info['name'];
      $this->uploaded_file['type'] = $this->image_size['mime'];
      $this->uploaded_file['file_path'] = $this->img_dir_upl . $this->uploaded_file['name'];
    }
  }

  function setLocalProductImage($passage = true) {
    //create adm_pics
    $this->createPicture(ADM_MIN);
    $this->createPicture(ADM_MED);
    //create pas_pics
    if ($passage) {
      $this->createPicture(PAS_MED, 'pas_');
      $this->createPicture(PAS_MAX, 'pas_');
    }
    //create shp_pics
    $this->createShopPictures();
  }

  function setLocalProducerImage() {

    //create adm_pics
//    $this->createPicture(ADM_MIN);
//    $this->createPicture(ADM_MED);
    //create shp_pics
    $this->setLocalImage();
  }

  function setLocalImage($type = 'producer') {

//    $this->ratioImage(200, 300, 'min_');
//    $this->createPicture(CMS_MED, 'cms_');
  }

  private function uploadProductImage() {

    $this->prepareUploadedFile();
    //create adm_pics
//    $this->createPicture(ADM_MIN);
    $this->createPicture(ADM_MED);
    $this->createPicture(GAL_MAX, 'gal_');
    $this->createPicture(GAL_MED, 'gal_');
    $this->createPicture(GAL_MIN, 'gal_');
    //create shp_pics
    //$this->createShopPictures();
  }

  private function uploadCmsImage() {

    $this->prepareUploadedFile();
    //create cms_pics
    $this->createPicture(CMS_MED, 'cms_');
  }

  private function uploadProducerImage() {

    $this->prepareUploadedFile();
    //create producer logos
    $this->createPicture(ADM_MIN, 'adm_');
    $this->createPicture(GAL_MIN, 'gal_');
    $this->createPicture(GAL_MED, 'gal_');
  }

  function uploadSliderImage() {

    $this->prepareUploadedFile();
    $this->createPicture(ADM_MIN);
    $this->createPicture(ADM_MED);
    $this->createPicture(SLIDER_MAX, 'slider_');
  }

  function uploadShopAds() {

    $this->prepareUploadedFile();
  }

  private
  function uploadImage($size, $prefix) {

    $this->prepareUploadedFile();
    //create adm_pics
    //create cms_pics
  }

  private
  function uploadSimpleFile($id, $file_field, $type) {

    $this->setUploadDir($id);
    if ($this->checkFileConditions($file_field, $type) === true) {
      $this->prepareUploadedFile();
      return $this->uploaded_file;
    }
  }

  // IMPORTANT!!! never set original filename with underscore
  function setFileName($ext = true) {

    if ($this->name_mode == 'uniq') {
      if (!$this->_seeded) {
        srand((double)microtime() * 1000000);
        $this->_seeded = 1;
      }
      $name = uniqid(rand());
      if ($ext) {
        $name .= ".{$this->uploaded_file['ext']}";
      }
    } else {
      $noalpha = 'ÁÉÍÓÚÝáéíóúýÂĘÎÔŰâęîôűŔČĚŇŮŕčěňůÄËĎÖÜäëďöü˙ĂăŐőĹĺŃńÇç@°şŞ';
      $alpha = 'AEIOUYaeiouyAEIOUaeiouAEIOUaeiouAEIOUaeiouyAaOoAaNnCcaooa';
      $name = $this->_file['name'];
      $name = strtr($name, $noalpha, $alpha);
      $name = preg_replace('/[^a-zA-Z0-9.\-]/', '-', strtolower($name));
    }
    return $name;
  }

  function moveFile($source_file, $dest_file, $move = true) {

    if ($move) {
      rename($this->img_dir_upl . $source_file, $dest_file);
    } else {
      copy($this->img_dir_upl . $source_file, $dest_file);
    }
  }

  function createPicture($size, $prefix = 'adm_') {

    $this->convertPicture($size, $prefix);
//    return true;
//    $prefix = $prefix . $size . '_';
//    $size = $this->parseSize($size);
//    if (!empty($size)) {
//      if ($size['width'] == $size['height']) {
//        $this->squareImage($size['width'], $prefix);
//      } else {
//        $this->ratioImage($size['width'], $size['height'], $prefix);
//      }
//    }
  }

  function createShopPictures() {

    //get info from settings -> sizes and watermark
    $o_Settings = new Settings();
    $settings = $o_Settings->getUstawienia('image');
    if (empty($settings) or empty($settings['img_min_size'])) {
      $settings['watermark'] = '';
      $settings['img_min_size'] = GAL_MIN;
      $settings['img_med_size'] = GAL_MED;
      $settings['img_max_size'] = GAL_MAX;
    }
    $this->createPicture($settings['img_min_size'], 'gal_');
    $this->createPicture($settings['img_med_size'], 'gal_');
    $this->createPicture($settings['img_max_size'], 'gal_');
    $this->addWaterMark($this->uploaded_file['name'], $settings['watermark']);
  }

  function parseSize($size) {

    if (preg_match("/(\dx\d)/", $size)) {
      list($width, $height) = preg_split('/x/', $size);
      if (is_numeric($width) and is_numeric($height)) {
        if ($width <= 500 and $height <= 500) {
          return array('width' => $width, 'height' => $height);
        }
      }
    }
    $this->setException(8, $size);
    return false;
  }

  /**
   * funkcja wczytujaca plik (dla CN - statycznej zmiany rozmiarow fotek
   * (w przyszlosci dorobic sprawdzanie podawanych warunkow!)
   *
   * @param string $post_file_name nazwa pola formularza
   *
   * @return array $file_prop - tablica danych dotyczacych uploadowanego pliku
   * todo check
   */
  function readFile($post_file_name, $dir = '') {

    if (!empty($dir)) {
      $this->img_dir_upl = $dir;
    }
    return $this->foto_prop = array(
      'name' => $post_file_name,
      'ext' => end(explode('.', $post_file_name)),
    );
  }

  function convertPicture($size, $prefix) {

    $prefix = $prefix . $size . '_';
    $file_img = $this->uploaded_file['file_path'];
    $file_min_img = $this->img_dir_upl . $prefix . $this->uploaded_file['name'];
    $cmd = " -resize \"{$size}>\"";
    exec("convert $file_img $cmd $file_min_img");
  }

  /**
   * @param string $image_data
   * @param string $orig_name
   * @param string string $dir
   * @return array
   * todo check
   */
  function readBase64String($image_data, $orig_name, $dir = '') {

    if (!empty($dir)) {
      $this->img_dir_upl = $dir;
    }
    $orig_name = preg_replace("/[^a-zA-Z0-9-\.]/i", '', $orig_name);
    $ifp = fopen($this->img_dir_upl . $orig_name, "wb");
    fwrite($ifp, base64_decode($image_data));
    fclose($ifp);
    return $this->foto_prop = array(
      'name' => $orig_name,
      'ext' => end(explode('.', $orig_name)),
    );
  }

  /**
   * wczytanie plikow jpg
   *
   * @param file $NewImg
   * @param string $path_img
   *
   * @return bool
   */
  function imagejpeg_new($NewImg, $path_img) {

//    imagejpeg($NewImg, $path_img.'.jpg', $this->quality);
//    return true;
    if ($this->uploaded_file['type'] == 'image/jpeg' or $this->uploaded_file['type'] == 'image/pjpeg') {
      imagejpeg($NewImg, $path_img, $this->quality);
    } elseif ($this->uploaded_file['type'] == 'image/gif') {
      imagegif($NewImg, $path_img);
    } elseif ($this->uploaded_file['type'] == 'image/png') {
      imagepng($NewImg, $path_img);
    } else {
      return (false);
    }
    return (true);
  }

  function imagecreatefromjpeg_new($path_img) {

    if ($this->uploaded_file['type'] == 'image/jpeg' or $this->uploaded_file['type'] == 'image/pjpeg') {
      $OldImg = imagecreatefromjpeg($path_img);
    } elseif ($this->uploaded_file['type'] == 'image/gif') {
      $OldImg = imagecreatefromgif($path_img);
    } elseif ($this->uploaded_file['type'] == 'image/png') {
      $OldImg = imagecreatefrompng($path_img);
    } else {
      return (false);
    }
    return ($OldImg);
  }

  /**
   * funkcja do tworzenia miniaturek!
   * w tej wersji funkcji tworze 3 zdjecia:
   * foto_min = 64px;
   * foto_srednie = 120px; (lub 100)
   * foto_big = 230px;
   *
   * Uwaga, w zaleznosci od parametru (np zdefiniowanego width_max - dostowac dodana fotke)
   * waterInfo = info dla zrobienia watermarka
   * $waterInfo['add'] = true;           //adding watermark to image file
   * $waterInfo['waterMarkText'] = "copyrighted";//the text to draw as watermark
   * $waterInfo['font'] = "arial.ttf";   //font file to use for drawing text. need absolute path
   * $waterInfo['size'] = 10;       //font size
   * $waterInfo['angle'] = 45;       //angle to draw watermark text
   * $waterInfo['hSpacing'] = 120;     //horizontal spacing betweeen two sucessive watermark text
   * $waterInfo['vSpacing'] = 120;     //vertical spacing betweeen two sucessive watermark text
   * $waterInfo['shadow'] = false;     //if set to true then a shadow will be drawn under every watermark text
   *
   *
   *
   *
   * @return err_no (zaimplementowac!):
   * -1 brak
   * 0 - ok
   * 1 - bad extension
   * 2 - bad sizes
   */
  function squareImage($new_rozm_img, $name_new_foto) {

    $file_img = $this->uploaded_file['file_path'];
    $file_min_img = $this->img_dir_upl . $name_new_foto . $this->uploaded_file['name'];
    $src_img = $this->imagecreatefromjpeg_new($file_img);
    if ($this->image_size[0] > $this->image_size[1]) {
      $dl_krawedz = $this->image_size[0];
    } else {
      $dl_krawedz = $this->image_size[1];
    }
    if ($src_img) {
      if ($dl_krawedz < $new_rozm_img) {
        $w = $this->image_size[0];
        $h = $this->image_size[1];
      } else {
        if ($this->image_size[0] > $this->image_size[1]) {
          $w = $new_rozm_img;
          $p = (imagesx($src_img) - $w) / imagesx($src_img);
          $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
        } else {
          $h = $new_rozm_img;
          $p = (imagesy($src_img) - $h) / imagesy($src_img);
          $w = imagesx($src_img) - floor(imagesx($src_img) * $p);
        }
      }
      if (($this->uploaded_file['ext'] == 'jpg') || ($this->uploaded_file['ext'] == 'jpeg')) {
        $dst_img = imagecreatetruecolor($new_rozm_img, $new_rozm_img);
        $back = imagecolorallocate($dst_img, 255, 255, 255);
        imagecolorallocate($dst_img, 0, 0, 0);
        imagefilledrectangle($dst_img, 0, 0, $new_rozm_img - 1, $new_rozm_img - 1, $back);
      } else {
        $dst_img = imagecreate($new_rozm_img, $new_rozm_img);
        imagecolorallocate($dst_img, 255, 255, 255);
      }
      $x = (int)(($new_rozm_img - $w) / 2);
      $y = (int)(($new_rozm_img - $h) / 2);
      imagecopyresampled($dst_img, $src_img, $x, $y, 0, 0, $w, $h, $this->image_size[0], $this->image_size[1]);
      $this->imagejpeg_new($dst_img, $file_min_img);
      imagedestroy($src_img);
      imagedestroy($dst_img);
    } else {
      $this->setException(9);
    }
    return true;
  }

  /**
   * dodaje watermark do obrazka
   *
   * @param string $file_img konkretny obrazek
   * @param array $waterInfo info do watermarkowania, w przypadku null, korzysta z wlasnych obrazkow
   *
   * return img
   */
  function addWaterMark($file_name, $water_text, $waterInnfo = null) {

//    $this->addWaterMark($file_min_img, $this->uploaded_file['ext'], $name_new_foto, $waterInfo);
    $file_img = $this->img_dir_upl . $file_name;
    copy($file_img, $this->img_dir_upl . 'panshop' . $file_name);
    $src_img = $this->imagecreatefromjpeg_new($file_img);
//    if (empty($waterInfo['waterMarkText'])) {
//      return true;
//    }
    if (empty($waterInfo['font'])) {
      $waterInfo['font'] = _VENDORS . 'fonts/verdana.ttf';
    }
    if (empty($waterInfo['size'])) {
      $waterInfo['size'] = 14;
    }
    if (empty($waterInfo['angle'])) {
      $waterInfo['angle'] = 0;
    }
    if (empty($waterInfo['hSpacing'])) {
      $waterInfo['hSpacing'] = 220;
    }
    if (empty($waterInfo['vSpacing'])) {
      $waterInfo['vSpacing'] = 220;
    }
    if (empty($waterInfo['shadow'])) {
      $waterInfo['shadow'] = false;
    }
    $grey = imagecolorallocate($src_img, 180, 180, 180); //color for watermark text
    $shadowColor = imagecolorallocate($src_img, 130, 130, 130); //color for shadow text
    imagettftext($src_img, $waterInfo['size'], $waterInfo['angle'],
      10, 20, $grey, $waterInfo['font'], $water_text);
    /*for ($x_wm = 20; $x_wm < $this->image_size[0]; $x_wm += $waterInfo['hSpacing']) {
      for ($y_wm = -10; $y_wm < $this->image_size[1]; $y_wm += $waterInfo['vSpacing']) {
        if ($waterInfo['shadow']) {
          //draw shadow text over image
          imagettftext($src_img, $waterInfo['size'],
            $waterInfo['angle'], $x_wm + 1, $y_wm + 1, $shadowColor,
            $waterInfo['font'], $water_text);
        }
        imagettftext($src_img, $waterInfo['size'], $waterInfo['angle'],
          $x_wm, $y_wm, $grey, $waterInfo['font'], $water_text);
      }
    }*/
//    unlink($file_img);
    $this->imagejpeg_new($src_img, $file_img);
    imagedestroy($src_img);
    return true;
  }

  /**
   * nowa funkcja do tworzenia dowolnych miniaturek
   *
   * @param int $NewWidth
   * @param int $NewHeight
   * @param string $name_new_foto
   * @param string $path
   * @return bool?
   */
  function ratioImage($NewWidth = 0, $NewHeight = 0, $name_new_foto, $path = '') {

    $orig_size = false; //czy resize'owac zdjecia (jesli rozmiar < size)
    if (!empty($path)) {
      $file_img = $path . $this->uploaded_file['name'];
    } else {
      $file_img = $this->uploaded_file['file_path'];
    }
    $file_min_img = $this->img_dir_upl . $name_new_foto . $this->uploaded_file['name'];
    $src_img = $this->imagecreatefromjpeg_new($file_img);
//    echo $file_min_img;
    if ($this->image_size[0] > $this->image_size[1]) {
      if ($this->image_size[0] > $NewWidth) {
        $w = $NewWidth;
        $p = (imagesx($src_img) - $w) / imagesx($src_img);
        $h = imagesy($src_img) - floor(imagesy($src_img) * $p);
      } else {
        $orig_size = true;
      }
    } else {
      if ($this->image_size[1] > $NewHeight) {
        $h = $NewHeight;
        $p = (imagesy($src_img) - $h) / imagesy($src_img);
        $w = imagesx($src_img) - floor(imagesx($src_img) * $p);
      } else {
        $orig_size = true;
      }
    }
    if ($orig_size === true) {
      $w = $this->image_size[0];
      $h = $this->image_size[1];
    }
    if (($this->uploaded_file['ext'] == 'jpg') || ($this->uploaded_file['ext'] == 'jpeg')) {
      $dst_img = imagecreatetruecolor($w, $h);
      $back = imagecolorallocate($dst_img, 255, 255, 255);
      imagecolorallocate($dst_img, 0, 0, 0);
      imagefilledrectangle($dst_img, 0, 0, $w - 1, $h - 1, $back);
    } else {
      $dst_img = imagecreate($w, $h);
      imagecolorallocate($dst_img, 255, 255, 255);
    }
    $dest_width = $w;
    $dest_height = $h;
    $src_width = $this->image_size[0];
    $src_height = $this->image_size[1];
    imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
    $this->imagejpeg_new($dst_img, $file_min_img);
    imagedestroy($src_img);
    imagedestroy($dst_img);
    return true;
  }

  /**
   * sciaga obrazek z zewnetrznego serwera i zapisuje na serwer
   *
   * @param string $imgurl
   * @param string $dir
   * @param string $picture_name
   * @param bool $wget
   *
   * @return bool
   */
  function downloadImage($img_url, $wget = true) {

    $img_name = $this->setFileName(false);
    $localimage = $this->img_dir_upl . $img_name;

    $curl = curl_init();
    $fp = fopen($localimage, "wb");
    curl_setopt($curl, CURLOPT_URL, $img_url);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 1);
    curl_setopt($curl, CURLOPT_BINARYTRANSFER, 1);
//    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($curl, CURLOPT_FILE, $fp);
    curl_exec($curl);
    curl_close($curl);
    fclose($fp);
    #/ *} else {*/
    #$cmd = 'wget --referer="http://www.google.com" --user-agent="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6" --header="Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5" --header="Accept-Language: en-us,en;q=0.5" --header="Accept-Charset: utf-8;q=0.7,*;q=0.7" --header="Keep-Alive: 300" ';
    #$cmd .= "-O \"{$localimage}\" \"{$img_url}\"";
//    echo $cmd . '<br>';
    #system($cmd);
//    echo $cmd;
    //} // end CURL check
    return $this->isImage($img_name, $localimage, $img_url);
  }

  function isImage($img_name, $localimage, $img_url = '') {

    if (is_file($localimage) and $this->image_size = getimagesize($localimage)) {
      switch ($this->image_size['mime']) {
        case 'image/gif':
          $ext = '.gif';
          break;
        case 'image/png':
          $ext = '.png';
          break;
        case 'image/x-png':
          $ext = '.png';
          break;
        case 'image/jpeg' || 'image/jpg' :
          $ext = '.jpg';
          break;
        default:
          unlink($localimage);
          $this->setException(12, $img_url);
          return false;
          break;
      }
      if (!empty($ext)) {
        rename($localimage, $localimage . $ext);
        return array('name' => $img_name . $ext, 'ext' => $ext);
      } else {
        unlink($localimage);
      }
    }
    return false;
  }

  function deleteFile($id, $name) {

    if (empty($name)) {
      return false;
    }
    $this->setUploadDir($id);
    $files = scandir($this->img_dir_upl);
    if (is_array($files)) {
      foreach ($files as $file) {
        if ($file != '.' and $file != '..') {
          if (preg_match("/$name/", $file)) {
            unlink($this->img_dir_upl . $file);
          }
        }
      }
    }
    return true;
  }
}