<?php

class SiteLang extends AdminEngine {

  function __construct() {

    parent::__construct();
  }

  /**
   *
   * @return array
   */
  public function findAll($limit = 50, $offset = 0) {

    return $this->selectAll('site_langs', array(), '*', '', $limit, $offset);
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array
   */
  public function find($id) {

    return $this->selectRow('site_langs', $id);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return mixed
   */
  public function create($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'name' => $name,
      'locale_name' => $locale_name,
      'is_active' => $is_active,
      'prefix' => $prefix,
    );
    return $this->autoInsertQuery('site_langs', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  public function update($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'name' => $name,
      'prefix' => $prefix,
      'locale_name' => $locale_name,
      'is_active' => $is_active,
    );
    return $this->autoUpdateQuery('site_langs', $fields, $id);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  public function delete($id) {

    return $this->autoDeleteQuery('site_langs', $id);
  }
}
