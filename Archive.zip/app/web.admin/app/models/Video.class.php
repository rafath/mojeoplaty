<?php

class Video extends AdminEngine {

  function __construct() {

    parent::__construct();

    $this->FileUpload = new FileUpload();
  }

  /**
   *
   * @return array $res
   */
  function getVideos($limit = 20, $offset = 0) {

    return $this->selectAll('videos', array(), '*', 'order by id DESC', $limit, $offset);
  }

  function parseData($data) {

    if (!empty($data['video_url'])) {
      $urls = preg_replace("/\r|\n/", "\n", $data['video_url']);
      $urls = preg_split("/\n/", $urls);
      $urls = array_filter($urls);
      if (count($urls) > 0) {
        //pobierz dane z urla
        foreach ($urls as $url) {
          $this->getVimeoData($url, $data['tag']);
        }
      }
    }
  }

  function setNew($id, $flag=1) {
    return $this->autoUpdateQuery('videos', array('is_new'=> $flag), $id);
  }


  function setSize($id, $size, $field='width') {
    return $this->autoUpdateQuery('videos', array($field=> (int)$size), $id);
  }

  function getVideo($id) {
    return $this->selectRow('videos', $id);
  }

  function getVimeoData($url, $tag) {
    $vimeo_url = 'http://vimeo.com/api/v2/video/';
    $url_parsed = preg_split('/\//', $url);
    $vimeo_id = end($url_parsed);
    $vimeo_xml = file_get_contents($vimeo_url.$vimeo_id.'.xml');
    $xml = simplexml_load_string($vimeo_xml);
    $this->createVideos($url, $vimeo_id, $xml, $tag);
//    $json = json_encode($xml);
//    $array = json_decode($json,TRUE);

  }

  /**
   * dodawanie danych do bazy
   *
   * @return bool
   */
  function createVideos($url, $id, $xml, $tag) {

    $this->FileUpload->prepareRemoteFile($xml->video->thumbnail_large, 0);
//    $this->FileUpload->setLocalImage();

    $fields = array(
      'video_id' => (int)$id,
      'video_url' => $url,
      'title' => titleize($xml->video->title),
      'description' => $xml->video->description,
      'picture' => $this->FileUpload->uploaded_file['name'],
      'picture_url' => $xml->video->thumbnail_large,
      'tag_name' => $tag,
      'upload_date' => $xml->video->upload_date,
      'width' => $xml->video->width,
      'height' => $xml->video->height,
    );
    return $this->autoInsertQuery('videos', $fields);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  function delVideo($id) {

    return $this->autoDeleteQuery('videos', $id);
  }
}
