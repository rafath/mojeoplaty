<?php
require_once _CONFIG . 'DB_Driver.php';

class AdminEngine extends DB_Driver {
  public $debuging = false; //funkcje maja generowac zapytania
  public $GLOBAL_CONFIG, $TABLES;
  public $lang_id;

  function __construct() {

    global $SQL, $_GLOBAL_CONFIG, $dbc;
    $this->dbh = $dbc;
    //redis
    $this->GLOBAL_CONFIG = $_GLOBAL_CONFIG;
    $this->TABLES = $SQL;
      $this->lang_id = $_SESSION['authinfo']['default_lang'];
  }

  function setFields(&$data = array()) {

    if (empty($this->fields)) {
      return false;
    }
    $fields = array_keys($this->fields);
    foreach ($data as $key => $value) {
      if (false === in_array($key, $fields)) {
        unset($data[$key]);
      } else {
        if (empty($data[$key])) {
          $value = $this->fields[$key]['default'];
        }
      }
    }
  }

  function setPicture($id, $old_picture, $new_picture, $delete = false) {

    if (!empty($new_picture) or $delete == true) {
      $this->deletePicture($id, $old_picture);
      $old_picture = $new_picture;
    }
    return $old_picture;
  }

  /**
   * funkcja do usuwania zdjec/plikow
   *
   * @param $id - sciezka do katalogu
   * @param $filename - nazwa pliku
   * @return bool
   */
  function deletePicture($id, $filename) {

    global $o_FileUpload;
    if (!is_object($o_FileUpload)) {
      $o_FileUpload = new FileUpload();
    }

    $o_FileUpload->deleteFile($id, $filename);
    return true;
  }

  function setCacheGen() {

    return true;
  }

  public function getLangs() {

    return $this->selectAssoc('site_langs', null, 'id, name', 'order by id asc');
  }
}