<?php

class Page extends AdminEngine {

  function __construct() {

    parent::__construct();
  }

  /**
   *
   * @return array $res
   */
  function getPages() {

    return $this->selectAll('pages', ['lang_id'=> $_SESSION['authinfo']['default_lang']],
      'id, parent, short_title, title, sorter, in_menu, lang_id', 'order by parent, sorter asc');
  }

  function getParents($with_blank = true, $all=false) {

    $new_parent = array();
    if ($with_blank) {
      $new_parent[0] = 'Nowa strona';
    }
    $cond = [];
    if ($all) {
      $cond['lang_id']= $this->lang_id;
    }

    $parents = $this->selectAssoc('pages', $cond, 'id, short_title', 'order by short_title');
    return $new_parent + $parents;
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array $res
   */
  function getPage($id) {

    return $this->selectRow('pages', $id);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return bool
   */
  function addPage($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'parent' => (int)$parent,
      'short_title' => $short_title,
      'title' => $title,
      'description' => $description,
      'seo_title' => $seo_title,
      'seo_description' => $seo_description,
      'seo_keywords' => $seo_keywords,
      'website_url' => $website_url,
      'theme_type' => $theme_type,
      'sorter' => (int)$sorter,
      'uri_token' => $uri_token,
      'is_active' => isset($is_active),
      'is_main' => isset($is_main),
      'in_menu' => isset($in_menu),
      'lang_id' => $lang_id,
    );
    if (isset($main_picture_file_name)) {
      $fields['main_picture_file_name'] = $main_picture_file_name;
    }
    if (isset($wide_picture_file_name)) {
      $fields['wide_picture_file_name'] = $wide_picture_file_name;
    }
    if (isset($site_picture_file_name)) {
      $fields['site_picture_file_name'] = $site_picture_file_name;
    }
    return $this->autoInsertQuery('pages', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  function editPage($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    if (isset($old_main_picture_file_name)) {
      $main_picture_file_name = $this->setPicture(0, $old_main_picture_file_name, $main_picture_file_name, isset($del_photo));
    } else {
      $main_picture_file_name = '';
    }
    if (isset($old_wide_picture_file_name)) {
      $wide_picture_file_name = $this->setPicture(0, $old_wide_picture_file_name, $wide_picture_file_name, isset($del_photo_1));
    } else {
      $wide_picture_file_name = '';
    }
    if (isset($old_site_picture_file_name)) {
      $site_picture_file_name = $this->setPicture(0, $old_site_picture_file_name, $site_picture_file_name, isset($del_photo_2));
    } else {
      $site_picture_file_name = '';
    }
    $fields = array(
      'parent' => (int)$parent,
      'short_title' => $short_title,
      'title' => $title,
      'description' => $description,
      'seo_title' => $seo_title,
      'seo_description' => $seo_description,
      'seo_keywords' => $seo_keywords,
      'main_picture_file_name' => $main_picture_file_name,
      'wide_picture_file_name' => $wide_picture_file_name,
      'site_picture_file_name' => $site_picture_file_name,
      'website_url' => $website_url,
      'theme_type' => $theme_type,
      'sorter' => (int)$sorter,
      'uri_token' => $uri_token,
      'is_active' => isset($is_active),
      'is_main' => isset($is_main),
      'in_menu' => isset($in_menu),
      'lang_id' => $lang_id,
    );
    return $this->autoUpdateQuery('pages', $fields, $id);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  function delPage($id) {

    return $this->autoDeleteQuery('pages', $id);
  }


  /**
   * wypisywanie kategorii
   *
   * @param int $pozycja
   * @param int $id_parenta
   * @return string?
   */
  function createCatsArray($pozycja, $id_parenta, $categories) {

    global $iteracja, $a_iter_cats;
    $cnt = count($categories);

    if (!isset($a_iter_cats)) {
      $a_iter_cats = array();
    }
    if (!isset($iteracja)) {
      $iteracja = 1;
    }
    $iteracja_prv = 1;
    for ($i = $pozycja; $i < $cnt; $i++) {
      if ($categories[$i]['parent'] == $id_parenta) {
        if (!isset($margin)) {
          $margin = '';
        }
        for ($j = 1; $j < $iteracja; $j++) {
          $margin .= '- ';
        }
        if ($categories[$i]['parent'] == 0) {
          $kat_name = $categories[$i]['short_title'];
        } else {
          $kat_name = '|' . $margin . $categories[$i]['short_title'];
        }
        $a_iter_cats[$categories[$i]['id']] = $kat_name;
        unset($margin);
        // +++++++++++++++++++++++++++++ /to_do
        $iteracja += $iteracja_prv;
        $this->createCatsArray($i + 1, $categories[$i]['id'], $categories);
      }
    }
    $iteracja -= $iteracja_prv;
    return $a_iter_cats;
  }
}

