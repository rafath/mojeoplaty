<?php

class Gallery extends AdminEngine {

  private $file_type;

  function __construct($file_type = 'image') {

    parent::__construct();
    $this->file_type = $file_type;
  }

  /**
   *
   * @return array $res
   */
  function getGalleries($article_id, $limit = 20, $offset = 0) {
    return $this->selectAll('galleries', array('article_id' => $article_id), '*', 'order by sorter', $limit, $offset);
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array $res
   */
  function getGallery($id, $name = false) {

    if (!empty($name)) {
      $where['picture_orig_name'] = $name;
      $where['article_id'] = $id;
    } else {
      $where = array('id' => $id);
    }
    return $this->selectRow('galleries', $where);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return bool
   */
  function createGallery($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'article_id' => (int)$article_id,
      'picture' => $picture,
      'picture_orig_name' => $picture_orig_name,
      'file_type' => $this->file_type,
    );
    return $this->autoInsertQuery('galleries', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  function updateGallery($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'article_id' => (int)$article_id,
      'picture' => $picture,
      'title' => $title,
      'sorter' => (int)$sorter,
      'description' => $description,
      'picture_orig_name' => $picture_orig_name,
      'file_type' => $this->file_type,
    );
    return $this->autoUpdateQuery('galleries', $fields, $id);
  }

  function setSorting($img_orders) {

    if (!empty($img_orders)) {
      $img_orders = explode('|', $img_orders);
      foreach ($img_orders as $sort => $id) {
        $this->autoUpdateQuery('galleries', ['sorter' => $sort], ['id' => $id]);
      }
    }
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  function delGallery($id, $name) {

    return $this->autoDeleteQuery('galleries', array('article_id' => $id, 'picture_orig_name' => $name));
  }

  function deleteImage($id) {

    $image = $this->getGallery($id);
    $this->deletePicture($image['article_id'], $image['picture']);
    return $this->autoDeleteQuery('galleries', array('id' => $id));
  }

  function addFile($file, $id, $title) {

    $fields = array(
      'article_id' => (int)$id,
      'picture' => $file,
      'title' => $title,
      'file_type' => $this->file_type,
    );
    return $this->autoInsertQuery('galleries', $fields);
  }
}
