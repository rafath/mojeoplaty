<?php

class Article extends AdminEngine {

  function __construct() {

    parent::__construct();
  }

  /**
   *
   * @return array $res
   */
  function getArticles($limit = 20, $offset = 0)   {

    return $this->selectAll('articles', array('lang_id'=> $this->lang_id), '*', 'order by id DESC', $limit, $offset);
//    return $this->selectAll('articles', [], '*', 'order by id DESC', $limit, $offset);
  }

  /**
   * pobranie wybranego rekordu
   *
   * @param int $id
   *
   * @return array $res
   */
  function getArticle($id) {

    return $this->selectRow('articles', $id);
  }

  /**
   * dodawanie danych do bazy
   *
   * @param array $a_data
   *
   * @return bool
   */
  function createArticle($a_data) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $fields = array(
      'page_id' => (int)$page_id,
      'seo_title' => $seo_title,
      'seo_keywords' => $seo_keywords,
      'seo_description' => $seo_description,
      'title' => $title,
      'short_description' => $short_description,
      'description' => $description,
      'uri_token' => $uri_token,
      'status' => (int)$status,
      'picture' => $picture,
      'sorter' => $sorter,
      'main_page' => isset($main_page) ? true : false,
      'lang_id'=> $this->lang_id
    );
    return $this->autoInsertQuery('articles', $fields);
  }

  /**
   * update tabeli
   *
   * @param array $a_data
   *
   * @return bool
   */
  function updateArticle($a_data, $id) {

    if (!is_array($a_data)) {
      return false;
    }
    extract($a_data);
    $picture = $this->setPicture(0, $old_picture, $picture, isset($del_photo));

    $fields = array(
      'page_id' => (int)$page_id,
      'seo_title' => $seo_title,
      'picture' => $picture,
      'sorter' => $sorter,
      'seo_keywords' => $seo_keywords,
      'seo_description' => $seo_description,
      'title' => $title,
      'short_description' => $short_description,
      'description' => $description,
      'uri_token' => $uri_token,
      'status' => (int)$status,
      'main_page' => isset($main_page) ? 1 : 0,
      'lang_id'=> $this->lang_id
    );
    return $this->autoUpdateQuery('articles', $fields, $id);
  }

  /**
   * usuwanie wybranej edycji
   *
   * @param int $id
   *
   * @return bool
   */
  function delArticle($id) {

    return $this->autoDeleteQuery('articles', $id);
  }
}
