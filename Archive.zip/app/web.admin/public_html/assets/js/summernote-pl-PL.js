(function ($) {
  $.extend($.summernote.lang, {
    'pl-PL': {
      font: {
        bold: 'Pogrubienie',
        italic: 'Pochylenie',
        underline: 'Podkreślenie',
        strikethrough: 'Przekreślenie',
        clear: 'Usuń formatowanie',
        height: 'Interlinia',
        name: 'Czcionka',
        size: 'Rozmiar'
      },
      image: {
        image: 'Grafika',
        insert: 'Wstaw grafikę',
        resizeFull: 'Zmień rozmiar na 100%',
        resizeHalf: 'Zmień rozmiar na 50%',
        resizeQuarter: 'Zmień rozmiar na 25%',
        floatLeft: 'Po lewej',
        floatRight: 'Po prawej',
        floatNone: 'Równo z tekstem',
        dragImageHere: 'Przeciągnij grafikę tutaj',
        selectFromFiles: 'Wybierz z dysku',
        url: 'URL grafiki',
        remove: 'Usuń grafikę'
      },
      link: {
        link: 'Odnośnik',
        insert: 'Wstaw odnośnik',
        unlink: 'Usuń odnośnik',
        edit: 'Edytuj',
        textToDisplay: 'Tekst do wyświetlenia',
        url: 'Na jaki URL powinien przenosić ten link?',
        openInNewWindow: 'Otwórz w nowym oknie'
      },
      video: {
        video: 'Wideo',
        videoLink: 'Adres wideo',
        insert: 'Wstaw wideo',
        url: 'Adres wideo',
        providers: '(YouTube, Vimeo, Vine, Instagram, lub DailyMotion)'
      },
      table: {
        table: 'Tabela'
      },
      hr: {
        insert: 'Wstaw poziomą linię'
      },
      style: {
        style: 'Style',
        normal: 'Normalny',
        blockquote: 'Cytat',
        pre: 'Kod',
        h1: 'Nagłówek 1',
        h2: 'Nagłówek 2',
        h3: 'Nagłówek 3',
        h4: 'Nagłówek 4',
        h5: 'Nagłówek 5',
        h6: 'Nagłówek 6'
      },
      lists: {
        unordered: 'Lista wypunktowana',
        ordered: 'Lista numerowana'
      },
      options: {
        help: 'Pomoc',
        fullscreen: 'Pełny ekran',
        codeview: 'Zródło'
      },
      paragraph: {
        paragraph: 'Akapit',
        outdent: 'Zmniejsz wcięcie',
        indent: 'Zwiększ wcięcie',
        left: 'Wyrównaj do lewej',
        center: 'Wyrównaj do środka',
        right: 'Wyrównaj do prawej',
        justify: 'Wyrównaj do lewej i prawej'
      },
      color: {
        recent: 'Ostani kolor',
        more: 'Więcej kolorów',
        background: 'Tło',
        foreground: 'Czcionka',
        transparent: 'Przeźroczysty',
        setTransparent: 'Przeźroczyste',
        reset: 'Reset',
        resetToDefault: 'Domyślne'
      },
      shortcut: {
        shortcuts: 'Skróty klawiszone',
        close: 'Zamknij',
        textFormatting: 'Formatowanie tekstu',
        action: 'Akcja',
        paragraphFormatting: 'Formatowanie akapitu',
        documentStyle: 'Styl dokumentu'
      },
      history: {
        undo: 'Cofnij',
        redo: 'Ponów'
      }
    }
  });
})(jQuery);

(function (factory) {
  /* global define */
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['jquery'], factory);
  } else {
    // Browser globals: jQuery
    factory(window.jQuery);
  }
}
(function ($) {
  // template, editor
  var tmpl = $.summernote.renderer.getTemplate();
  var editor = $.summernote.eventHandler.getEditor();
  // core functions: range, dom
  var range = $.summernote.core.range;
  var dom = $.summernote.core.dom;
  /**
   * createVideoNode
   *
   * @member plugin.video
   * @private
   * @param {String} url
   * @return {Node}
   */
  var createVideoNode = function (url) {
    // video url patterns(youtube, instagram, vimeo, dailymotion, youku, mp4, ogg, webm)
    var ytRegExp = /^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
    var ytMatch = url.match(ytRegExp);
    var igRegExp = /\/\/instagram.com\/p\/(.[a-zA-Z0-9]*)/;
    var igMatch = url.match(igRegExp);
    var vRegExp = /\/\/vine.co\/v\/(.[a-zA-Z0-9]*)/;
    var vMatch = url.match(vRegExp);
    var vimRegExp = /\/\/(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/;
    var vimMatch = url.match(vimRegExp);
    var dmRegExp = /.+dailymotion.com\/(video|hub)\/([^_]+)[^#]*(#video=([^_&]+))?/;
    var dmMatch = url.match(dmRegExp);
    var youkuRegExp = /\/\/v\.youku\.com\/v_show\/id_(\w+)\.html/;
    var youkuMatch = url.match(youkuRegExp);
    var mp4RegExp = /^.+.(mp4|m4v)$/;
    var mp4Match = url.match(mp4RegExp);
    var oggRegExp = /^.+.(ogg|ogv)$/;
    var oggMatch = url.match(oggRegExp);
    var webmRegExp = /^.+.(webm)$/;
    var webmMatch = url.match(webmRegExp);
    var $video;
    if (ytMatch && ytMatch[1].length === 11) {
      var youtubeId = ytMatch[1];
      $video = $('<iframe>')
          .attr('frameborder', 0)
          .attr('src', '//www.youtube.com/embed/' + youtubeId)
          .attr('width', '640').attr('height', '360');
    } else {
      if (igMatch && igMatch[0].length) {
        $video = $('<iframe>')
            .attr('frameborder', 0)
            .attr('src', igMatch[0] + '/embed/')
            .attr('width', '612').attr('height', '710')
            .attr('scrolling', 'no')
            .attr('allowtransparency', 'true');
      } else {
        if (vMatch && vMatch[0].length) {
          $video = $('<iframe>')
              .attr('frameborder', 0)
              .attr('src', vMatch[0] + '/embed/simple')
              .attr('width', '600').attr('height', '600')
              .attr('class', 'vine-embed');
        } else {
          if (vimMatch && vimMatch[3].length) {
            $video = $('<iframe webkitallowfullscreen mozallowfullscreen allowfullscreen>')
                .attr('frameborder', 0)
                .attr('src', '//player.vimeo.com/video/' + vimMatch[3])
                .attr('width', '640').attr('height', '360');
          } else {
            if (dmMatch && dmMatch[2].length) {
              $video = $('<iframe>')
                  .attr('frameborder', 0)
                  .attr('src', '//www.dailymotion.com/embed/video/' + dmMatch[2])
                  .attr('width', '640').attr('height', '360');
            } else {
              if (youkuMatch && youkuMatch[1].length) {
                $video = $('<iframe webkitallowfullscreen mozallowfullscreen allowfullscreen>')
                    .attr('frameborder', 0)
                    .attr('height', '498')
                    .attr('width', '510')
                    .attr('src', '//player.youku.com/embed/' + youkuMatch[1]);
              } else {
                if (mp4Match || oggMatch || webmMatch) {
                  $video = $('<video controls>')
                      .attr('src', url)
                      .attr('width', '640').attr('height', '360');
                } else {
                  // this is not a known video link. Now what, Cat? Now what?
                }
              }
            }
          }
        }
      }
    }
    return $video[0];
  };
  /**
   * @member plugin.video
   * @private
   * @param {jQuery} $editable
   * @return {String}
   */
  var getTextOnRange = function ($editable) {
    $editable.focus();
    var rng = range.create();
    // if range on anchor, expand range with anchor
    if (rng.isOnAnchor()) {
      var anchor = dom.ancestor(rng.sc, dom.isAnchor);
      rng = range.createFromNode(anchor);
    }
    return rng.toString();
  };
  /**
   * toggle button status
   *
   * @member plugin.video
   * @private
   * @param {jQuery} $btn
   * @param {Boolean} isEnable
   */
  var toggleBtn = function ($btn, isEnable) {
    $btn.toggleClass('disabled', !isEnable);
    $btn.attr('disabled', !isEnable);
  };
  /**
   * Show video dialog and set event handlers on dialog controls.
   *
   * @member plugin.video
   * @private
   * @param {jQuery} $dialog
   * @param {jQuery} $dialog
   * @param {Object} text
   * @return {Promise}
   */
  var showVideoDialog = function ($editable, $dialog, text) {
    return $.Deferred(function (deferred) {
      var $videoDialog = $dialog.find('.note-video-dialog');
      var $videoUrl = $videoDialog.find('.note-video-url'),
          $videoBtn = $videoDialog.find('.note-video-btn');
      $videoDialog.one('shown.bs.modal', function () {
        $videoUrl.val(text).on('input', function () {
          toggleBtn($videoBtn, $videoUrl.val());
        }).trigger('focus');
        $videoBtn.click(function (event) {
          event.preventDefault();
          deferred.resolve($videoUrl.val());
          $videoDialog.modal('hide');
        });
      }).one('hidden.bs.modal', function () {
        $videoUrl.off('input');
        $videoBtn.off('click');
        if (deferred.state() === 'pending') {
          deferred.reject();
        }
      }).modal('show');
    });
  };
  (function (factory) {
    /* global define */
    if (typeof define === 'function' && define.amd) {
      // AMD. Register as an anonymous module.
      define(['jquery'], factory);
    } else {
      // Browser globals: jQuery
      factory(window.jQuery);
    }
  }(function ($) {
    // template
    var tmpl = $.summernote.renderer.getTemplate();
    // core functions: range, dom
    var range = $.summernote.core.range;
    var dom = $.summernote.core.dom;
    /**
     * createVideoNode
     *
     * @member plugin.video
     * @private
     * @param {String} url
     * @return {Node}
     */
    var createVideoNode = function (url) {
      // video url patterns(youtube, instagram, vimeo, dailymotion, youku, mp4, ogg, webm)
      var ytRegExp = /^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
      var ytMatch = url.match(ytRegExp);
      var igRegExp = /\/\/instagram.com\/p\/(.[a-zA-Z0-9]*)/;
      var igMatch = url.match(igRegExp);
      var vRegExp = /\/\/vine.co\/v\/(.[a-zA-Z0-9]*)/;
      var vMatch = url.match(vRegExp);
      var vimRegExp = /\/\/(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/;
      var vimMatch = url.match(vimRegExp);
      var dmRegExp = /.+dailymotion.com\/(video|hub)\/([^_]+)[^#]*(#video=([^_&]+))?/;
      var dmMatch = url.match(dmRegExp);
      var youkuRegExp = /\/\/v\.youku\.com\/v_show\/id_(\w+)\.html/;
      var youkuMatch = url.match(youkuRegExp);
      var mp4RegExp = /^.+.(mp4|m4v)$/;
      var mp4Match = url.match(mp4RegExp);
      var oggRegExp = /^.+.(ogg|ogv)$/;
      var oggMatch = url.match(oggRegExp);
      var webmRegExp = /^.+.(webm)$/;
      var webmMatch = url.match(webmRegExp);
      var $video;
      if (ytMatch && ytMatch[1].length === 11) {
        var youtubeId = ytMatch[1];
        $video = $('<iframe>')
            .attr('frameborder', 0)
            .attr('src', '//www.youtube.com/embed/' + youtubeId)
            .attr('width', '640').attr('height', '360');
      } else {
        if (igMatch && igMatch[0].length) {
          $video = $('<iframe>')
              .attr('frameborder', 0)
              .attr('src', igMatch[0] + '/embed/')
              .attr('width', '612').attr('height', '710')
              .attr('scrolling', 'no')
              .attr('allowtransparency', 'true');
        } else {
          if (vMatch && vMatch[0].length) {
            $video = $('<iframe>')
                .attr('frameborder', 0)
                .attr('src', vMatch[0] + '/embed/simple')
                .attr('width', '600').attr('height', '600')
                .attr('class', 'vine-embed');
          } else {
            if (vimMatch && vimMatch[3].length) {
              $video = $('<iframe webkitallowfullscreen mozallowfullscreen allowfullscreen>')
                  .attr('frameborder', 0)
                  .attr('src', '//player.vimeo.com/video/' + vimMatch[3])
                  .attr('width', '640').attr('height', '360');
            } else {
              if (dmMatch && dmMatch[2].length) {
                $video = $('<iframe>')
                    .attr('frameborder', 0)
                    .attr('src', '//www.dailymotion.com/embed/video/' + dmMatch[2])
                    .attr('width', '640').attr('height', '360');
              } else {
                if (youkuMatch && youkuMatch[1].length) {
                  $video = $('<iframe webkitallowfullscreen mozallowfullscreen allowfullscreen>')
                      .attr('frameborder', 0)
                      .attr('height', '498')
                      .attr('width', '510')
                      .attr('src', '//player.youku.com/embed/' + youkuMatch[1]);
                } else {
                  if (mp4Match || oggMatch || webmMatch) {
                    $video = $('<video controls>')
                        .attr('src', url)
                        .attr('width', '640').attr('height', '360');
                  } else {
                    // this is not a known video link. Now what, Cat? Now what?
                    return false;
                  }
                }
              }
            }
          }
        }
      }
      return $video[0];
    };
    /**
     * @member plugin.video
     * @private
     * @param {jQuery} $editable
     * @return {String}
     */
    var getTextOnRange = function ($editable) {
      $editable.focus();
      var rng = range.create();
      // if range on anchor, expand range with anchor
      if (rng.isOnAnchor()) {
        var anchor = dom.ancestor(rng.sc, dom.isAnchor);
        rng = range.createFromNode(anchor);
      }
      return rng.toString();
    };
    /**
     * toggle button status
     *
     * @member plugin.video
     * @private
     * @param {jQuery} $btn
     * @param {Boolean} isEnable
     */
    var toggleBtn = function ($btn, isEnable) {
      $btn.toggleClass('disabled', !isEnable);
      $btn.attr('disabled', !isEnable);
    };
    /**
     * Show video dialog and set event handlers on dialog controls.
     *
     * @member plugin.video
     * @private
     * @param {jQuery} $dialog
     * @param {jQuery} $dialog
     * @param {Object} text
     * @return {Promise}
     */
    var showVideoDialog = function ($editable, $dialog, text) {
      return $.Deferred(function (deferred) {
        var $videoDialog = $dialog.find('.note-video-dialog');
        var $videoUrl = $videoDialog.find('.note-video-url'),
            $videoBtn = $videoDialog.find('.note-video-btn');
        $videoDialog.one('shown.bs.modal', function () {
          $videoUrl.val(text).on('input', function () {
            toggleBtn($videoBtn, $videoUrl.val());
          }).trigger('focus');
          $videoBtn.click(function (event) {
            event.preventDefault();
            deferred.resolve($videoUrl.val());
            $videoDialog.modal('hide');
          });
        }).one('hidden.bs.modal', function () {
          $videoUrl.off('input');
          $videoBtn.off('click');
          if (deferred.state() === 'pending') {
            deferred.reject();
          }
        }).modal('show');
      });
    };

    $.summernote.addPlugin({
                             /** @property {String} name name of plugin */
                             name: 'video',
                             /**
                              * @property {Object} buttons
                              * @property {function(object): string} buttons.video
                              */
                             buttons: {
                               video: function (lang) {
                                 return tmpl.iconButton('fa fa-youtube-play', {
                                   event: 'showVideoDialog',
                                   title: lang.video.video,
                                   hide: true
                                 });
                               }
                             },
                             /**
                              * @property {Object} dialogs
                              * @property {function(object, object): string} dialogs.video
                              */
                             dialogs: {
                               video: function (lang) {
                                 var body = '<div class="form-group row-fluid">' +
                                            '<label>' + lang.video.url + ' <small class="text-muted">' + lang.video.providers + '</small></label>' +
                                            '<input class="note-video-url form-control span12" type="text" />' +
                                            '</div>';
                                 var footer = '<button href="#" class="btn btn-primary note-video-btn disabled" disabled>' + lang.video.insert + '</button>';
                                 return tmpl.dialog('note-video-dialog', lang.video.insert, body, footer);
                               }
                             },
                             /**
                              * @property {Object} events
                              * @property {Function} events.showVideoDialog
                              */
                             events: {
                               showVideoDialog: function (event, editor, layoutInfo) {
                                 var $dialog = layoutInfo.dialog(),
                                     $editable = layoutInfo.editable(),
                                     text = getTextOnRange($editable);
                                 // save current range
                                 editor.saveRange($editable);
                                 showVideoDialog($editable, $dialog, text).then(function (url) {
                                   // when ok button clicked
                                   // restore range
                                   editor.restoreRange($editable);
                                   // build node
                                   var $node = createVideoNode(url);
                                   if ($node) {
                                     // insert video node
                                     editor.insertNode($editable, $node);
                                   }
                                 }).fail(function () {
                                   // when cancel button clicked
                                   editor.restoreRange($editable);
                                 });
                               }
                             },
                             // define language
                             langs: {
                               'en-US': {
                                 video: {
                                   video: 'Video',
                                   videoLink: 'Video Link',
                                   insert: 'Insert Video',
                                   url: 'Video URL?',
                                   providers: '(YouTube, Vimeo, Vine, Instagram, DailyMotion or Youku)'
                                 }
                               },
                               'pl-PL': {
                                 video: {
                                   video: 'Wideo',
                                   videoLink: 'Adres wideo',
                                   insert: 'Wstaw wideo',
                                   url: 'Adres wideo',
                                   providers: '(YouTube, Vimeo, Vine, Instagram, DailyMotion, lub Youku)'
                                 }
                               }
                           }
                           });
  }))}));
