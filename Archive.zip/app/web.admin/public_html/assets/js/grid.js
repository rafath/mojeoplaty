$(function () {
  if ($('#gallery-images').length) {
    var container = document.getElementById("gallery-images");
    var sort = Sortable.create(container, {
      animation: 150,
      handle: ".tile__title",
      draggable: ".tile",
      store: {
        get: function (sortable) {
          var order = localStorage.getItem(sortable.options.group);
          return order ? order.split('|') : [];
        },
        set: function (sortable) {
          var order = sortable.toArray();
          localStorage.setItem(sortable.options.group, order.join('|'));
          $.post('new_article/', {
            d: 3,
            id: $(container).attr('data-article-id'),
            sorter: localStorage.getItem(sortable.options.group)
          }, function (res) {
            //console.log(res);
          }, 'html');
          console.log(localStorage.getItem(sortable.options.group));
        }
      }
    });
  }
});
