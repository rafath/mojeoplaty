$(document).ready(function() {
	$('.pattern').parallax("50%", 0, 0.1, true);
});