class Invoice < ActiveRecord::Base

  belongs_to :user
end
