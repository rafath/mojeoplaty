class EmailMessage < ActiveRecord::Base

  belongs_to :user

end
